# Operations Log

## [2026-11-11 14:26:03] ingest | KT-sdk-and-entitlements.md

## [2026-11-11 14:27:46] ingest | ARC-portal-service-relationships.md

## [2026-11-11 14:28:36] ingest | KT-frontend-composition.md

## [2026-11-11 14:30:19] ingest | KT-portal-purpose.md

## [2026-11-11 14:31:41] ingest | KT-architecture-evolution.md

## [2026-11-11 14:32:54] ingest | KT-application-interoperability.md

## [2026-11-11 14:33:59] ingest | KT-observability-and-performance.md

## [2026-11-11 14:35:40] ingest | KT-admin-and-onboarding.md

## [2026-11-11 14:37:30] ingest | KT-release-operations.md

## [2026-11-11 14:38:23] ingest | REQ-active-session-renewal.md

## [2026-11-11 14:40:06] ingest | KT-authentication-and-sessions.md

## [2026-11-11 14:41:25] ingest | KT-ces-migration-parity.md

## [2026-11-11 14:42:53] query | What is the candidate target behavior for active session renewal after refresh-token expiry, including manual recovery?

## [2026-11-11 14:44:23] query | How should the candidate CES migration preserve EMS2 permission meaning, and what equivalence limits remain?

## [2026-11-11 14:44:43] query | What are the candidate Portal frontend layers and their ownership boundaries?

## [2026-11-11 14:45:14] query | What responsibilities do Portal and tenant teams have during routing, validation, onboarding, and release?

## [2026-11-11 14:45:38] query | What candidate contract is required for application interoperability and OpenFin context readiness?

## [2026-11-11 14:46:04] query | What do the candidate records say about portal interaction analytics, cache behavior, and performance evidence?

## [2026-11-11 14:48:34] lint | report → lint_20261111_144834.md

## [2026-11-11 14:57:10] query | How should the Portal preserve an active session across refresh-token expiry, and what manual recovery is required after a rejected renewal?

## [2026-11-11 14:57:54] query | What candidate mapping rules map EMS2 roles and entitlements to CES permissions, and what parity limits remain unresolved?

## [2026-11-11 14:58:20] query | What are the Portal frontend composition layers and ownership boundaries among root config, base, container, feature, module, and tile?

## [2026-11-11 14:58:38] query | Which responsibilities belong to Portal and tenant teams for routing, release, validation, and rollback?

## [2026-11-11 14:58:56] query | What candidate interoperability contract and OpenFin/FDC3 context readiness are required between caller and provider applications?

## [2026-11-11 14:59:16] query | What telemetry and performance or capacity evidence exists for portal interactions, cache behavior, and response time, and what remains proposed or missing?

