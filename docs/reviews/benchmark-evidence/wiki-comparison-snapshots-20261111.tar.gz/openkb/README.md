# OpenKB Benchmark Snapshot

This is the generated OpenKB output from the 11 November 2026 benchmark, retained for comparison and audit. It was compiled from 12 candidate records; raw inputs were symlinked from `knowledge/candidates` and were not copied.

The OpenKB CLI, runtime configuration, raw symlink, and mutable working state have been removed. This snapshot is not an active knowledge store or a source of approved policy. Its original `AGENTS.md` is retained as `wiki/OPENKB_AGENTS_ARCHIVED.md` so it does not act as live project instructions.

See the [benchmark report](../../QMD_OPENKB_BENCHMARK_20261111.md) and [llm-wiki comparison](../../LLM_WIKI_DIRECT_COMPARISON_20261111.md).
