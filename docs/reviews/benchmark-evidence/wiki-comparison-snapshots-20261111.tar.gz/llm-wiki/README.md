# Former llm-wiki output snapshot

This is the former active wiki from `knowledge/llm-wiki/`, retained when OpenKB became Workbench's primary wiki on 11 November 2026. It is comparison evidence, not an active knowledge store.

The original Markdown pages, operation log, graph outputs, and export manifest are retained byte-for-byte. `inventory.json` records their hashes and original workspace path. Relative source links inside the preserved pages use that original workspace context; use the export manifest's project-relative `origin` entries to locate canonical records.

`implementation/wiki.py` preserves the former exporter from Workbench revision `86f686b9d01f8faedf805ee67df28dfb631ddbea`, with its source path and hash in the inventory. It demonstrates the deterministic export behavior reviewed in the [comparison report](../../QMD_OPENKB_BENCHMARK_20261111.md).

The active [OpenKB catalog](../../../../knowledge/llm-wiki/wiki/index.md) contains the replacement compilation. The original llm-wiki-agent source remains unchanged under `.agents/skills/llm-wiki/upstream/`.
