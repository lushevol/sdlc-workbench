import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { createServer } from 'node:http';
import { access, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

const root = path.dirname(fileURLToPath(import.meta.url));
// Resolve before importing Playwright. Startup never installs packages or browsers.
process.env.PLAYWRIGHT_BROWSERS_PATH = path.join(root, '.browsers');
const ignoredBackgroundDefaults = [
  '--disable-background-timer-throttling',
  '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding',
];
const sha256 = value => createHash('sha256').update(value).digest('hex');
const json = value => JSON.stringify(value, null, 2) + '\n';
const launchOptions = browser => ({
  headless: false,
  chromiumSandbox: true,
  ...(browser === 'msedge' ? { channel: 'msedge' } : {}),
  ignoreDefaultArgs: ignoredBackgroundDefaults,
});
function channel(value) {
  if (!['chromium', 'msedge'].includes(value)) throw new Error('Select chromium or msedge.');
  return value;
}
function git(...args) {
  try { return execFileSync('git', ['-C', root, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); }
  catch { return null; }
}
async function runtime() {
  const { chromium } = await import('playwright');
  const packageInfo = JSON.parse(await readFile(path.join(root, 'node_modules/playwright/package.json')));
  return { chromium, packageInfo };
}
async function doctor() {
  const { chromium, packageInfo } = await runtime();
  const executable = chromium.executablePath();
  let chromiumPresent = true;
  try { await access(executable, constants.X_OK); } catch { chromiumPresent = false; }
  const edgeCandidates = process.platform === 'darwin'
    ? ['/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
    : process.platform === 'win32'
      ? [process.env['PROGRAMFILES(X86)'], process.env.PROGRAMFILES, process.env.LOCALAPPDATA]
        .filter(Boolean).map(base => path.join(base, 'Microsoft/Edge/Application/msedge.exe'))
      : ['/opt/microsoft/msedge/msedge'];
  let edge = null;
  for (const candidate of edgeCandidates) {
    try { await access(candidate, constants.X_OK); edge = candidate; break; } catch { /* Try next declared location. */ }
  }
  const result = {
    status: chromiumPresent && edge ? 'READY' : 'INCOMPLETE',
    checked_at: new Date().toISOString(), platform: process.platform, arch: process.arch,
    os_release: os.release(), node: process.version, playwright: packageInfo.version,
    chromium: { present: chromiumPresent, executable }, edge: { present: Boolean(edge), executable: edge },
    browser_launch_tested: false,
    limitations: ['Presence checks do not establish browser launch or business behavior.'],
  };
  console.log(json(result));
  if (result.status !== 'READY') process.exitCode = 1;
}

// The fixture contains no credentials, external resources, or business behavior.
const fixture = `<!doctype html><html lang="en"><meta charset="utf-8">
<title>Workbench browser tooling smoke</title>
<style>body{font:20px system-ui;margin:60px;line-height:1.6}button{font:inherit}</style>
<h1>Workbench browser tooling smoke</h1>
<p>This local fixture checks browser tooling.</p><button>Confirm browser control</button>
<p id="result" role="status">Waiting for a click</p>
<script>
window.observations = [];
function record(event) {
  window.observations.push({event, at:new Date().toISOString(), monotonic_ms:performance.now(),
    visibility:document.visibilityState, focused:document.hasFocus()});
}
record('load');
for (const event of ['visibilitychange','freeze','resume','pagehide','pageshow']) {
  document.addEventListener(event, () => record(event));
}
document.querySelector('button').onclick = () => {
  document.querySelector('#result').textContent = 'Browser control confirmed'; record('click');
};
</script></html>`;

async function smoke(browser, output) {
  const { chromium, packageInfo } = await runtime();
  // Exclusive creation preserves earlier evidence.
  await mkdir(output, { recursive: false });
  const sourceNames = ['browser.mjs', 'package.json', 'package-lock.json'];
  const sourceHashes = Object.fromEntries(await Promise.all(sourceNames.map(async name => [name, sha256(await readFile(path.join(root, name)))])));
  const report = {
    kind: 'controlled-local-tooling-smoke', status: 'FAILED', started_at: new Date().toISOString(),
    browser, playwright: packageInfo.version, node: process.version, platform: process.platform,
    arch: process.arch, os_release: os.release(), source: { head: git('rev-parse', 'HEAD'), files: sourceHashes },
    launch_options: launchOptions(browser), profile: 'Playwright temporary profile; removed on close',
    focus_emulation: 'Disabled through CDP on these isolated targets to permit native visibility changes.',
    assertions: [],
    limitations: [
      'This short smoke does not reproduce the portal incident or verify business behavior.',
      'Automation defaults differ from a personal browser. Only three background-related defaults are removed.',
      'A tab switch does not establish natural freezing or a 30-minute background interval.',
    ],
  };
  let context;
  let instance;
  let profile;
  let tracing = false;
  const server = createServer((request, response) => {
    response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(request.url === '/other' ? '<!doctype html><title>Other tab</title><h1>Other tab</h1>' : fixture);
  });
  try {
    await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
    report.origin = `http://127.0.0.1:${server.address().port}`;
    profile = await mkdtemp(path.join(os.tmpdir(), 'workbench-browser-smoke-'));
    context = await chromium.launchPersistentContext(profile, { ...launchOptions(browser), viewport: { width: 1100, height: 760 } });
    instance = context.browser();
    report.browser_version = instance.version();
    await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
    tracing = true;
    const page = context.pages()[0] ?? await context.newPage();
    const pageSession = await context.newCDPSession(page);
    await pageSession.send('Emulation.setFocusEmulationEnabled', { enabled: false });
    await page.goto(report.origin);
    report.user_agent = await page.evaluate(() => navigator.userAgent);
    await page.getByRole('button', { name: 'Confirm browser control' }).click();
    assert.equal(await page.getByRole('status').textContent(), 'Browser control confirmed');
    report.assertions.push('Role locator click changes the visible status text.');
    const otherOpened = context.waitForEvent('page');
    await page.evaluate(url => { window.open(url, '_blank'); }, `${report.origin}/other`);
    const other = await otherOpened;
    const otherSession = await context.newCDPSession(other);
    await otherSession.send('Emulation.setFocusEmulationEnabled', { enabled: false });
    await other.waitForLoadState();
    await page.bringToFront();
    await page.waitForFunction(() => document.visibilityState === 'visible');
    const hidden = page.waitForFunction(() => document.visibilityState === 'hidden', null, { polling: 100, timeout: 5000 });
    report.switch_requested_at = new Date().toISOString();
    await other.bringToFront();
    await hidden;
    // Native timer in the visible second tab; no clock changes or forced lifecycle events.
    await other.evaluate(() => new Promise(resolve => setTimeout(resolve, 2000)));
    report.return_requested_at = new Date().toISOString();
    await page.bringToFront();
    await page.waitForFunction(() => document.visibilityState === 'visible');
    report.observations = await page.evaluate(() => window.observations);
    const hiddenEvent = report.observations.find(event => event.visibility === 'hidden');
    const returnEvent = report.observations.find(event => hiddenEvent && event.monotonic_ms > hiddenEvent.monotonic_ms && event.visibility === 'visible');
    assert.ok(hiddenEvent && returnEvent, 'Expected timestamped hidden and visible observations.');
    report.hidden_interval_ms = returnEvent.monotonic_ms - hiddenEvent.monotonic_ms;
    assert.ok(report.hidden_interval_ms >= 2000, 'Expected at least 2000 ms in the background.');
    report.assertions.push('Native visibility events record hidden, then visible, at least 2000 ms apart.');
    await writeFile(path.join(output, 'snapshot.yaml'), await page.locator('body').ariaSnapshot());
    await page.screenshot({ path: path.join(output, 'returned.png') });
    report.status = 'PASSED';
  } catch (error) {
    report.error = String(error);
    if (context) report.page_states = await Promise.all(context.pages().map(async page => ({
      url: page.url(), ...await page.evaluate(() => ({ visibility: document.visibilityState, focused: document.hasFocus(), observations: window.observations })),
    }))).catch(() => []);
    process.exitCode = 1;
  } finally {
    if (tracing) await context.tracing.stop({ path: path.join(output, 'trace.zip') });
    await context?.close();
    if (profile) await rm(profile, { recursive: true, force: true });
    await new Promise(resolve => server.close(resolve));
    report.finished_at = new Date().toISOString();
    await writeFile(path.join(output, 'result.json'), json(report));
    const artifacts = {};
    for (const name of ['result.json', 'snapshot.yaml', 'returned.png', 'trace.zip']) {
      try { const bytes = await readFile(path.join(output, name)); artifacts[name] = { sha256: sha256(bytes), size_bytes: bytes.length }; }
      catch { /* Failed runs can have partial evidence. */ }
    }
    await writeFile(path.join(output, 'manifest.json'), json({ schema_version: 1, artifacts }));
    console.log(json({ ...report, output }));
  }
}

async function agent(browser, commands) {
  const allowed = ['open', 'goto', 'snapshot', 'find', 'click', 'fill', 'press', 'tab-new', 'tab-select', 'tab-list', 'screenshot', 'tracing-start', 'tracing-stop', 'close', 'run-code', 'console', 'requests'];
  if (!allowed.includes(commands[0])) throw new Error(`Select an agent command: ${allowed.join(', ')}.`);
  if (commands.some(arg => /^--?(profile|persistent|extension|cdp|endpoint|config|browser|user-data-dir)(=|$)/.test(arg))) {
    throw new Error('The agent wrapper requires its own isolated profile and configuration.');
  }
  await runtime();
  const output = path.join(root, 'evidence');
  await mkdir(output, { recursive: true });
  const config = path.join(output, `agent-${browser}.json`);
  await writeFile(config, json({ browser: { browserName: 'chromium', isolated: true, launchOptions: launchOptions(browser) }, outputDir: output }));
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => !/^(PLAYWRIGHT_MCP_|PWTEST_CLI_)/.test(name)));
  env.PWTEST_CLI_GLOBAL_CONFIG = output;
  const args = [path.join(root, 'node_modules/playwright/cli.js'), 'cli', `-s=workbench-${browser}`, ...commands];
  if (commands[0] === 'open') args.push(`--config=${config}`);
  const child = spawn(process.execPath, args, { cwd: root, stdio: 'inherit', env });
  process.exitCode = await new Promise((resolve, reject) => { child.once('error', reject); child.once('exit', code => resolve(code ?? 1)); });
}

try {
  const [mode = 'doctor', ...rest] = process.argv.slice(2);
  if (mode === 'agent') {
    await agent(channel(rest[0]), rest.slice(1));
  } else {
    const { values } = parseArgs({ args: rest, options: { browser: { type: 'string', default: 'chromium' }, output: { type: 'string' } } });
    if (mode === 'doctor') await doctor();
    else if (mode === 'smoke') {
      const browser = channel(values.browser);
      const output = values.output ? path.resolve(values.output) : path.join(root, 'evidence', `${Date.now()}-${browser}`);
      await mkdir(path.dirname(output), { recursive: true });
      await smoke(browser, output);
    } else throw new Error('Use doctor, smoke [--browser chromium|msedge] [--output NEW_PATH], or agent chromium|msedge COMMAND.');
  }
} catch (error) {
  console.error(String(error));
  process.exitCode = 1;
}
