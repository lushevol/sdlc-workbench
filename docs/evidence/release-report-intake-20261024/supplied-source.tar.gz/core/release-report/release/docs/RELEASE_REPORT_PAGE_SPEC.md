# Release Report Page – Business Analyst Specification

## Purpose
Provide a comprehensive, visually organized, and responsive page for viewing release details, supporting engineering, QA, and management workflows.

---

## Key Data Sections

### 1. Header
- **Title:** Release Report
- **Breadcrumb navigation:** Home / Releases / [Release ID]

### 2. Release Overview
- **Release ID:** Prominently displayed
- **CR Number:** Change Request identifier
- **Planned Date:** Scheduled release date
- **Current Status:** (e.g., Planned, In Progress, Completed, Failed)
- **Approval Status:** (e.g., Pending, Approved, Rejected)

*Layout:* Use a responsive card or grid with clear labels and values.

### 3. Deployed Components
- Table or list of all components included in the release:
  - Component Name
  - Version/Build Number
  - Deployment Status (Success/Failed/Pending)
  - Last Updated

*Layout:* Use [`Table`](../components/ui/table.tsx) or [`Card`](../components/ui/card.tsx) from shadcn.

### 4. Build Status
- Visual indicator (badge, icon, or progress bar)
- Build Number/ID
- Timestamp
- Link to build logs (if available)

### 5. Sonar Issues
- Section for code quality issues identified by SonarQube:
  - Issue Type (Bug, Vulnerability, Code Smell)
  - Severity
  - Component/Module
  - Description
  - Status (Open/Resolved)
- Optionally, summary stats (total issues, critical, etc.)

*Layout:* Use a collapsible panel or tabbed section for clarity.

---

## UI/UX Guidelines

- **Responsiveness:** All sections must stack vertically on mobile, use grid/flex layouts for desktop.
- **Visual Hierarchy:** Use shadcn [`Card`](../components/ui/card.tsx), [`Badge`](../components/ui/badge.tsx), and [`Table`](../components/ui/table.tsx) components for clarity.
- **Styling:** Apply Tailwind CSS for spacing, typography, and color. Align with the ratan-workbench design system.
- **Accessibility:** Ensure semantic HTML, keyboard navigation, and ARIA labels where needed.
- **Interactivity:** 
  - Collapsible/expandable sections for Sonar issues.
  - Hover states for table rows.
  - Status badges with color coding (e.g., green for success, red for failed).

---

## Wireframe Example

```
---------------------------------------------------------
| Release Report                                        |
| Home / Releases / [Release ID]                        |
---------------------------------------------------------
| Release Overview                                      |
| ----------------------------------------------------- |
| Release ID | CR Number | Planned Date | Status | ...  |
| ----------------------------------------------------- |
---------------------------------------------------------
| Deployed Components                                   |
| ----------------------------------------------------- |
| Name | Version | Status | Last Updated                |
| ----------------------------------------------------- |
---------------------------------------------------------
| Build Status                                          |
| [Badge] Build #1234 | 2025-08-20 10:00 | [Logs Link]  |
---------------------------------------------------------
| Sonar Issues [Collapsible]                            |
| ----------------------------------------------------- |
| Type | Severity | Component | Description | Status    |
| ----------------------------------------------------- |
| Total Issues: | Critical: | High: | Medium: | Low:  |
| ----------------------------------------------------- |
| Summary Stats: | 0 | 0 | 0 | 0 |
---------------------------------------------------------
```

---

## Acceptance Criteria

- All required data points are displayed in clearly separated sections.
- Page is visually organized and responsive on all devices.
- Uses shadcn and Tailwind CSS components.
- Statuses and issues are color-coded and easy to scan.
- Sonar issues section is collapsible for better UX.
- Follows the ratan-workbench design system.

---

*Document prepared by Business Analyst for ratan-workbench Release Report Page*