export interface ReleaseGraphRepoNode {
  id: string;
  label: string;
  type: "repo";
  repo: string;
}

export interface ReleaseGraphCommitNode {
  id: string;
  label: string;
  type: "commit";
  repo: string;
  commitId: string;
}

export interface ReleaseGraphFileNode {
  id: string;
  label: string;
  type: "file";
  repo: string;
  commitId: string;
  path: string;
}

export interface ReleaseGraphStoryNode {
  id: string;
  label: string;
  type: "story";
  storyId: number;
}

export interface ReleaseGraphTestCaseNode {
  id: string;
  label: string;
  type: "testCase";
  testCaseId: number;
}

export type ReleaseGraphNode =
  | ReleaseGraphRepoNode
  | ReleaseGraphCommitNode
  | ReleaseGraphFileNode
  | ReleaseGraphStoryNode
  | ReleaseGraphTestCaseNode;

export interface ReleaseGraphEdge {
  id: string;
  type: string;
  from: string;
  to: string;
  metadata?: Record<string, unknown>;
}

export interface ReleaseGraphResponse {
  release: string;
  nodes: ReleaseGraphNode[];
  edges: ReleaseGraphEdge[];
  meta: {
    counts: {
      repos: number;
      commits: number;
      files: number;
      stories: number;
      testCases: number;
      edges: number;
    };
    warnings: string[];
    unresolvedStoryIds: number[];
    unlinkedCommits: string[];
  };
}