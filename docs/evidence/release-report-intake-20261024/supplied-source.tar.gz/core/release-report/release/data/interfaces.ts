import type {
  DefectStatusStats,
  ReleaseComplianceGateKey,
  ReleaseComplianceOverallStatus,
  ReleaseComplianceStatus,
  ReleaseWorkItemType,
  TestExecutionStatusStats,
} from "ratan-ado-api";

export type ReleaseCoverageMetrics = {
  coverage?: number;
  line_coverage?: number;
  branch_coverage?: number;
};

// export type PullRequest = {
//   id: number;
//   title: string;
//   sourceBranch: string;
//   targetBranch: string;
//   description: string;
//   status: number;
//   reviewResult: ReviewResultJson | null;
// };

type GitCommitDiffs = {
  aheadCount?: number;
  allChangesIncluded?: boolean;
  baseCommit?: string;
  behindCount?: number;
  changeCounts?: {
    [key: number]: number;
  };
  commonCommit?: string;
  targetCommit?: string;
};

export type ReleaseReport = {
  release: ReleaseWorkItemType;
  compliance: ReleaseReportCompliance | null;
  workitems: {
    id: number;
    title: string;
    type: string;
    state: string;
    testExecutionStatusStats: TestExecutionStatusStats;
    defectStatusStats: DefectStatusStats;
  }[];
  builds: {
    id: number;
    url: string;
    status: string;
    repo: string;
    buildNumber: string;
    result: string;
    startTime: string;
    finishTime: string;
    sourceBranch: string;
    sourceVersion: string;
    prodMeasures?: ReleaseCoverageMetrics;
    measures?: ReleaseCoverageMetrics;
    // pullRequest: PullRequest;

    diffs: {
      diffWithLatestCommit: GitCommitDiffs;
      diffWithReleasedProd: GitCommitDiffs;
      diffWithMainBranch: GitCommitDiffs | null;
      mainDiffWithProd: GitCommitDiffs | null;
      behindMainAllMergeCommit: boolean | null;
      behindProdAllMergeCommit: boolean | null;
      mainBehindProdAllMergeCommit: boolean | null;
      latestBranchCommit: string;
      mainBranchCommit: string | null;
      prodCommit: string;
      prodBranch: string;
    };
  }[];
};

export type ReleaseReportCompliance = {
  overallStatus: ReleaseComplianceOverallStatus;
  checks: ReleaseReportComplianceCheck[];
  linkedStoryCount: number;
};

export type ReleaseReportComplianceCheck = {
  key: ReleaseComplianceGateKey;
  label: string;
  status: ReleaseComplianceStatus;
};
