import type { ReleaseWorkItemType } from "ratan-ado-api";
import type {
  ReleaseReportCompliance,
  ReleaseReportComplianceCheck,
} from "./interfaces";

const PASS = "PASS";
const FAIL = "FAIL";
const WARN = "WARN";
const INFO = "INFO";

type GuidanceByStatus = Partial<
  Record<ReleaseReportComplianceCheck["status"], readonly [string, string]>
>;

const GUIDANCE: Record<string, GuidanceByStatus> = {
  NewQuestionnaire: {
    FAIL: [
      "Security questionnaire not using the new template.",
      "Open the Release WI security assessment tab, switch the new questionnaire field to Yes, and attach the latest completed template.",
    ],
  },
  SecurityControls: {
    INFO: [
      "No security controls were auto-detected for this release.",
      "Verify the security assessment tab still reflects the real deployment scope. Auto-detection can miss custom deployment paths.",
    ],
  },
  RollbackDoc: {
    FAIL: [
      "Rollback documentation is missing or invalid.",
      "Add a valid rollback runbook link in the AIG and Rollback Document Link field, and ensure rollback.md exists in the deployment repository if required.",
    ],
    WARN: [
      "Rollback information needs review.",
      "Confirm the rollback link is present and points to a usable runbook. If rollback is genuinely not applicable, document the reason explicitly.",
    ],
  },
  CtrlDocsSigned: {
    FAIL: [
      "Release control documents are not confirmed as attached and signed off.",
      "Attach the required release control documents and tick the confirmation checkbox in the release work item.",
    ],
  },
  CHGID: {
    FAIL: [
      "No ServiceNow Change Request ID has been entered.",
      "Create or link the required change request and populate the CHG ID field before pre-release checks run.",
    ],
  },
  TestRationale: {
    FAIL: [
      "Mandatory test exclusions have no rationale.",
      "Populate the rationale field for excluded mandatory tests with a release-specific justification.",
    ],
    WARN: [
      "Test exclusion rationale should be reviewed.",
      "Make sure any rationale is specific and defensible rather than a generic not-applicable note.",
    ],
  },
  SIExpiry: {
    WARN: [
      "Solution intent or another exception needs review.",
      "Work with the solution architect and security stakeholders to resolve or renew the flagged exception before the next release cycle.",
    ],
  },
  SCApproval: {
    FAIL: [
      "Security Champion approval has not been recorded.",
      "Confirm all triggered controls are resolved and that the release has reached compliant security status so the approval date can be set.",
    ],
    WARN: [
      "Security Champion approval needs follow-up.",
      "If this release required manual review, confirm a human reviewer has validated the release and countersigned where needed.",
    ],
  },
  SCHuman: {},
  POApproval: {
    FAIL: [
      "Product Owner approval is missing.",
      "Ask the Product Owner to approve the release in the release approvals section.",
    ],
  },
  TSOApproval: {
    FAIL: [
      "Technology Service Owner approval is missing.",
      "Have the TSO approve the release in the release approvals section.",
    ],
  },
  TSUOApproval: {
    FAIL: [
      "Technology Service Usage Owner approval is missing.",
      "Have the TSUO approve the release in the release approvals section.",
    ],
  },
  SVS: {
    FAIL: [
      "Security validation is not compliant.",
      "Review open security controls and complete the missing security work before attempting release approval again.",
    ],
    WARN: [
      "Security validation is accepted with risk rather than compliant.",
      "Confirm the risk acceptance is valid, time-bounded, and tracked for closure.",
    ],
  },
  SAValidity: {
    FAIL: [
      "Security assessment validity has expired.",
      "Start a new security assessment review and update the validity date once the review is complete.",
    ],
    WARN: [
      "Security assessment validity date is not set.",
      "Update the validity date in the security assessment section after the review is complete.",
    ],
  },
} as const;

const CHECK_META = {
  NewQuestionnaire: ["New Questionnaire", "Gate 1 - Security Questionnaire", false],
  SecurityControls: ["Security Controls", "Gate 2 - Security Controls", false],
  RollbackDoc: ["Rollback Doc", "Gate 3 - Release Candidate", true],
  CtrlDocsSigned: ["Release Ctrl Docs Signed", "Gate 3 - Release Candidate", true],
  CHGID: ["CHG ID", "Gate 4 - Pre-Release", true],
  TestRationale: ["Test Excl. Rationale", "Gate 4 - Pre-Release", false],
  SIExpiry: ["SI / Exceptions", "Gate 4 - Pre-Release", false],
  SCApproval: ["SC Approval Date", "Gate 5 - Approvals", true],
  SCHuman: ["SC Reviewer", "Gate 5 - Approvals", false],
  POApproval: ["PO Approval", "Gate 5 - Approvals", false],
  TSOApproval: ["TSO Approval", "Gate 5 - Approvals", false],
  TSUOApproval: ["TSUO Approval", "Gate 5 - Approvals", false],
  SVS: ["Security Status", "Gate 5 - Approvals", true],
  SAValidity: ["SA Validity Date", "Gate 5 - Approvals", false],
} as const;

const CHECK_ORDER = Object.keys(CHECK_META) as AuditCheckKey[];

const COMPLIANCE_TO_AUDIT_KEY = {
  "SQ-1:NewQuestionnaire": "NewQuestionnaire",
  "SC-1:ApplicableControls": "SecurityControls",
  "PRC-9:RollbackDoc": "RollbackDoc",
  "PRC-10:CtrlDocsSigned": "CtrlDocsSigned",
  "PR-1:CHGID": "CHGID",
  "PR-4:ExcludedTestRationale": "TestRationale",
  "PR-5:SIExpiry": "SIExpiry",
  "RA-1:SecurityChampion": "SCApproval",
  "RA-2:SCHuman": "SCHuman",
  "RA-3:POApproval": "POApproval",
  "RA-4:TSOApproval": "TSOApproval",
  "RA-5:TSUOApproval": "TSUOApproval",
  "RA-6:SecurityStatus": "SVS",
  "RA-7:SAssessmentValidity": "SAValidity",
} as const satisfies Record<string, AuditCheckKey>;

type AuditCheckKey = keyof typeof CHECK_META;

export type AuditCard = {
  key: AuditCheckKey;
  title: string;
  gate: string;
  critical: boolean;
  effectiveCritical: boolean;
  status: ReleaseReportComplianceCheck["status"];
  evidence: string;
  gap: string;
  guidance: string;
};

export type AuditOverview = {
  overallStatus: ReleaseReportCompliance["overallStatus"];
  linkedStoryCount: number;
  releaseLabel: string;
  hive: string;
  squad: string;
  cards: AuditCard[];
  hiddenExtraCheckCount: number;
  summary: {
    critical: number;
    fail: number;
    warn: number;
    pass: number;
  };
};

function getAuditCardSortRank(card: AuditCard): number {
  if (card.effectiveCritical) {
    return 0;
  }

  if (card.status === FAIL) {
    return 1;
  }

  if (card.status === WARN) {
    return 2;
  }

  if (card.status === PASS) {
    return 3;
  }

  return 4;
}

export function parseHiveSquad(areaPath?: string): {
  hive: string;
  squad: string;
} {
  const parts = String(areaPath || "").split("\\");
  const hive =
    parts.find((part) => part.includes("(HIVE)")) ||
    (parts.length > 1 ? parts[1] : String(areaPath || ""));
  const squad = parts.length > 2 ? parts.at(-1) || "" : "";
  return { hive, squad };
}

export function getComplianceStatusClasses(status?: string): string {
  if (status === "COMPLIANT") {
    return "bg-green-600 text-white";
  }

  if (status === "COMPLIANT WITH WARNINGS") {
    return "bg-yellow-500 text-white";
  }

  if (status?.includes("NON-COMPLIANT")) {
    return "bg-red-600 text-white";
  }

  return "bg-gray-500 text-white";
}

export function getAuditStatusClasses(
  status: ReleaseReportComplianceCheck["status"],
): string {
  if (status === FAIL) {
    return "border-red-200 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300";
  }

  if (status === WARN) {
    return "border-yellow-200 bg-yellow-50 text-yellow-700 dark:border-yellow-900 dark:bg-yellow-950/40 dark:text-yellow-300";
  }

  if (status === PASS) {
    return "border-green-200 bg-green-50 text-green-700 dark:border-green-900 dark:bg-green-950/40 dark:text-green-300";
  }

  return "border-gray-200 bg-gray-50 text-gray-700 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300";
}

export function buildAuditOverview(
  release: ReleaseWorkItemType,
  compliance: ReleaseReportCompliance,
): AuditOverview {
  const { hive, squad } = parseHiveSquad(release.areaPath);
  const checks = compliance.checks ?? [];
  const checkMap = new Map(checks.map((check) => [check.key, check]));

  const cards = CHECK_ORDER.map((auditKey) =>
    buildAuditCard(release, auditKey, checkMap),
  ).sort((leftCard, rightCard) => {
    return getAuditCardSortRank(leftCard) - getAuditCardSortRank(rightCard);
  });

  const extraChecks = checks.filter(
    (check) => !(check.key in COMPLIANCE_TO_AUDIT_KEY),
  );
  const allChecks = [...cards, ...extraChecks.map((check) => ({ status: check.status }))];

  return {
    overallStatus: compliance.overallStatus,
    linkedStoryCount: compliance.linkedStoryCount,
    releaseLabel: release.changeId || String(release.id || "Unknown"),
    hive,
    squad,
    cards,
    hiddenExtraCheckCount: extraChecks.length,
    summary: {
      critical: cards.filter((card) => card.effectiveCritical)
        .length,
      fail: allChecks.filter((check) => check.status === FAIL).length,
      warn: allChecks.filter((check) => check.status === WARN).length,
      pass: allChecks.filter((check) => check.status === PASS).length,
    },
  };
}

function buildAuditCard(
  release: ReleaseWorkItemType,
  auditKey: AuditCheckKey,
  checkMap: Map<string, ReleaseReportComplianceCheck>,
): AuditCard {
  const summaryCheck = getSummaryCheckForAuditKey(auditKey, checkMap);
  const [title, gate, critical] = CHECK_META[auditKey];
  const status = summaryCheck?.status ?? INFO;
  const [gap = "", guidance = ""] = GUIDANCE[auditKey]?.[status] || [];
  const effectiveCritical = critical && status === FAIL;

  return {
    key: auditKey,
    title,
    gate,
    critical,
    effectiveCritical,
    status,
    evidence: buildEvidence(release, auditKey, status),
    gap,
    guidance,
  };
}

function getSummaryCheckForAuditKey(
  auditKey: AuditCheckKey,
  checkMap: Map<string, ReleaseReportComplianceCheck>,
): ReleaseReportComplianceCheck | undefined {
  const matchingEntry = Object.entries(COMPLIANCE_TO_AUDIT_KEY).find(
    ([, mappedAuditKey]) => mappedAuditKey === auditKey,
  );

  if (!matchingEntry) {
    return undefined;
  }

  return checkMap.get(matchingEntry[0]);
}

function buildEvidence(
  release: ReleaseWorkItemType,
  auditKey: AuditCheckKey,
  status: ReleaseReportComplianceCheck["status"],
): string {
  const applicableSecurityControls = release.applicableSecurityControls ?? [];
  const deploymentComponents = release.deploymentComponents ?? [];
  const testingTypeInScope = release.testingtypeinscope ?? [];

  switch (auditKey) {
    case "NewQuestionnaire":
      return `Questionnaire check status: ${status}.`;
    case "SecurityControls":
      return `Detected security controls: ${applicableSecurityControls.length} item(s).`;
    case "RollbackDoc":
      return `Deployment components listed: ${deploymentComponents.length} item(s).`;
    case "CtrlDocsSigned":
      return `Release state: ${release.state || "Unknown"}`;
    case "CHGID":
      return release.changeId
        ? "Release is linked to a change identifier."
        : "Release does not currently show a linked change identifier.";
    case "TestRationale":
      return `Testing in scope: ${testingTypeInScope.length} declared type(s).`;
    case "SIExpiry":
      return "Exception state derived from the compliance evaluation.";
    case "SCApproval":
      return release.securityChampionReviewer?.displayName
        ? "A Security Champion reviewer is associated with this release."
        : "No Security Champion reviewer is currently visible on this release.";
    case "SCHuman":
      return release.securityChampionReviewer?.displayName
        ? "Reviewer identity is present on the release."
        : "Reviewer identity is not currently visible on the release.";
    case "POApproval":
      return `PO approval: ${release.poApproval || "Not set"}`;
    case "TSOApproval":
      return `TSO approval: ${release.tsoApproval || "Not set"}`;
    case "TSUOApproval":
      return `TSUO approval: ${release.tsuoApproval || "Not set"}`;
    case "SVS":
      return `Release state: ${release.state || "Unknown"}`;
    case "SAValidity":
      return `Planned release date: ${release.plannedReleaseDate || "Not set"}`;
    default:
      return `Compliance status: ${status}`;
  }
}
