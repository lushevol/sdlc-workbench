import {
  IconClock,
  IconUserCheck,
  IconUsers,
  IconUserX,
} from "@tabler/icons-react";
import { useQueries, useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import dayjs from "dayjs";
import { Header } from "@/components/layout/header";
import { Main } from "@/components/layout/main";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { Search } from "@/components/search";
import { ThemeSwitch } from "@/components/theme-switch";
import { Separator } from "@/components/ui/separator";
import type { AdoReleaseWorkItem } from "@/gql/graphql";
import { Route } from "@/routes/_authenticated/release/board";
import {
  releaseIdListQueryOptions,
  releaseQueryOptions,
} from "./api/queryRelease";

// Helper for approvals
const supervisorFields: Array<{
  name: string;
  approvedField:
    | "securityChampionApproval"
    | "poApproval"
    | "tsoApproval"
    | "tsuoApproval";
  reviewerField:
    | "securityChampionReviewer"
    | "poReviewer"
    | "tsoReviewer"
    | "tsuoReviewer";
}> = [
  // {
  //   name: "Security Champion",
  //   approvedField: "securityChampionApproval",
  //   reviewerField: "securityChampionReviewer",
  // },
  {
    name: "PO",
    approvedField: "poApproval",
    reviewerField: "poReviewer",
  },
  {
    name: "TSO",
    approvedField: "tsoApproval",
    reviewerField: "tsoReviewer",
  },
  {
    name: "TSUO",
    approvedField: "tsuoApproval",
    reviewerField: "tsuoReviewer",
  },
];

export default function ReleaseList() {
  const navigate = useNavigate({ from: Route.path });
  const { from: searchFrom, to: searchTo } = Route.useSearch();
  const from = searchFrom ?? dayjs().format("YYYY-MM-DD");
  const to = searchTo ?? dayjs().add(7, "days").format("YYYY-MM-DD");
  const { data, isLoading } = useQuery(releaseIdListQueryOptions(from, to));
  const releaseIds = data?.queryRatanReleaseIds ?? [];

  const releaseQueries = useQueries({
    queries: releaseIds.map((id) => releaseQueryOptions(Number(id))),
  });
  const releases = releaseQueries
    .filter((q) => q.status === "success")
    .map((q) => q.data?.adoRelease)
    .filter(Boolean)
    .sort((a, b) => {
      const dateA = dayjs(a?.plannedReleaseDate);
      const dateB = dayjs(b?.plannedReleaseDate);
      if (dateA.isBefore(dateB)) return -1;
      if (dateA.isAfter(dateB)) return 1;
      // If plannedReleaseDate is the same, sort by release id
      return Number(a?.id) - Number(b?.id);
    }) as AdoReleaseWorkItem[];

  return (
    <>
      <Header>
        <Search />
        <div className="ml-auto flex items-center gap-4">
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>
      <Main fixed>
        <div className="mb-2 flex items-center justify-between space-y-2">
          <h1 className="text-2xl font-bold tracking-tight">Release Board</h1>
          <div className="flex flex-wrap items-center gap-4 mb-4">
            <button
              type="button"
              className="px-3 py-2 rounded-md border border-input bg-background text-sm shadow-sm transition-colors hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/20"
              onClick={() => {
                navigate({
                  search: (prev) => ({
                    ...prev,
                    from: dayjs(from).subtract(7, "days").format("YYYY-MM-DD"),
                    to: dayjs(to).subtract(7, "days").format("YYYY-MM-DD"),
                  }),
                });
              }}
              aria-label="Previous 7 days"
            >
              &lt;- Prev Week
            </button>
            <div className="flex flex-row justify-center items-center gap-2">
              <input
                id="from-date"
                name="from"
                type="date"
                className="shadcn-input w-40 rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
                value={from ?? ""}
                onChange={(e) => {
                  navigate({
                    search: (prev) => ({
                      ...prev,
                      from: e.target.value || undefined,
                    }),
                  });
                }}
                aria-label="Select start date"
              />
            </div>
            <span className="text-xl text-muted-foreground select-none">
              -&gt;
            </span>
            <div className="flex flex-row justify-center items-center gap-2">
              <input
                id="to-date"
                name="to"
                type="date"
                className="shadcn-input w-40 rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
                value={to ?? ""}
                onChange={(e) => {
                  navigate({
                    search: (prev) => ({
                      ...prev,
                      to: e.target.value || undefined,
                    }),
                  });
                }}
                aria-label="Select end date"
              />
            </div>
            <button
              type="button"
              className="px-3 py-2 rounded-md border border-input bg-background text-sm shadow-sm transition-colors hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/20"
              onClick={() => {
                navigate({
                  search: (prev) => ({
                    ...prev,
                    from: dayjs(from).add(7, "days").format("YYYY-MM-DD"),
                    to: dayjs(to).add(7, "days").format("YYYY-MM-DD"),
                  }),
                });
              }}
              aria-label="Next 7 days"
            >
              Next Week -&gt;
            </button>
            {(searchFrom || searchTo) && (
              <button
                type="button"
                className="ml-2 px-3 py-2 rounded-md border border-input bg-background text-sm shadow-sm transition-colors hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/20"
                onClick={() => {
                  navigate({
                    search: () => ({
                      from: undefined,
                      to: undefined,
                    }),
                  });
                }}
                aria-label="Clear search"
              >
                Clear
              </button>
            )}
          </div>
        </div>
        <Separator className="my-4 shadow-sm" />
        <ul className="faded-bottom no-scrollbar grid gap-6 overflow-auto pt-4 pb-16 sm:grid-cols-1 md:grid-cols-2">
          {isLoading && (
            <div className="animate-pulse text-muted-foreground">
              Loading...
            </div>
          )}
          {releaseIds.length === 0 && !isLoading && (
            <div className="text-muted-foreground">No releases found.</div>
          )}
          {releases.map((release) => {
            // Approval logic
            const pendingApprovals = supervisorFields
              .filter((field) => release[field.approvedField] !== "Yes")
              .map((field) => ({
                name: field.name,
                reviewer: release[field.reviewerField],
              }));
            const hasApprovalException = pendingApprovals.length > 0;

            // Performance Test: Use testingTypeInScope and rationale
            const ptInScope = release.testingtypeinscope?.includes(
              "Performance Testing",
            );
            return (
              <li
                key={release.id}
                className="relative flex flex-col rounded-xl border bg-background p-6 shadow-sm transition-shadow hover:shadow-lg min-w-0 cursor-pointer"
                tabIndex={0}
                role="button"
                aria-label={`View details for release ${release.changeId}`}
                onClick={() => navigate({ to: `/release/${release.id}` })}
                onKeyUp={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    navigate({ to: `/release/${release.id}` });
                  }
                }}
              >
                {/* Top Row: ID, Plan Date, State */}
                <div className="flex flex-wrap items-center justify-between mb-2 gap-y-2 min-w-0">
                  <span className="text-xs font-mono text-muted-foreground truncate max-w-[50%]">
                    {release.id}
                  </span>
                  <div className="flex flex-nowrap items-center gap-2 min-w-0">
                    <span
                      className="inline-flex items-center gap-1 rounded bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground whitespace-nowrap"
                      title="Planned Release Date"
                    >
                      <IconClock size={14} className="opacity-70" />
                      {release.plannedReleaseDate}
                    </span>
                    <span
                      className={`inline-flex items-center rounded px-2 py-0.5 text-xs font-semibold whitespace-nowrap ${
                        release.state === "Released"
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                          : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                      }`}
                    >
                      {release.state}
                    </span>
                  </div>
                </div>
                {/* Title */}
                <h2 className="mb-1 mt-1 text-lg font-semibold leading-tight truncate">
                  {release.title}
                </h2>
                {/* Status Bar */}
                <div className="mb-3 mt-2 flex flex-wrap gap-2 min-w-0">
                  {/* Approval State */}
                  <div
                    className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-medium min-w-0 max-w-full truncate ${
                      hasApprovalException
                        ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                        : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    }`}
                    title={
                      hasApprovalException
                        ? `Pending: ${pendingApprovals
                            .map((s) => s.reviewer)
                            .join(", ")}`
                        : "All supervisors approved"
                    }
                  >
                    <IconUsers size={15} />
                    <span className="truncate">
                      {pendingApprovals.length > 0
                        ? `${pendingApprovals.length} Pending`
                        : "Approved"}
                    </span>
                  </div>
                  {/* Code Quality State */}
                  {/* <div
                    className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-medium min-w-0 max-w-full truncate ${
                      hasCodeQualityException
                        ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                        : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    }`}
                    title={
                      hasCodeQualityException
                        ? "No pipeline runs"
                        : "All code quality gates passed"
                    }
                  >
                    <IconCode size={15} />
                    <span>{hasCodeQualityException ? "Missing CI" : "OK"}</span>
                  </div> */}
                  {/* PR Review State */}
                  {/* <div
                    className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-medium min-w-0 max-w-full truncate ${
                      hasPrReviewException
                        ? "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
                        : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    }`}
                    title={
                      hasPrReviewException
                        ? `${release.comments?.length} Comments`
                        : "All PR issues fixed"
                    }
                  >
                    <IconGitPullRequest size={15} />
                    <span className="truncate">
                      {hasPrReviewException
                        ? `${release.comments?.length} PR Issues`
                        : "Clean"}
                    </span>
                  </div> */}
                  {/* Performance Test State */}
                  <div
                    className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-medium min-w-0 max-w-full truncate ${
                      ptInScope
                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                        : "bg-muted text-muted-foreground"
                    }`}
                    title={
                      !ptInScope ? "No Performance Test" : "Performance Test"
                    }
                  >
                    <svg
                      width={15}
                      height={15}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="inline-block"
                      aria-hidden="true"
                      focusable="false"
                    >
                      <title>Performance Test</title>
                      <circle cx="12" cy="12" r="10" />
                      <path d="M12 6v6l4 2" />
                    </svg>
                    {!ptInScope ? "No PT" : "PT"}
                  </div>
                </div>
                {/* Approval Details */}
                <div className="mb-2 flex flex-wrap gap-2 items-center min-w-0">
                  {supervisorFields.map((field) =>
                    release[field.approvedField] === "Yes" ? (
                      <span
                        key={field.name}
                        className="flex items-center gap-1 text-green-600 dark:text-green-300 text-xs truncate"
                        title={`${field.name}: Approved by ${release[field.reviewerField]?.displayName}`}
                      >
                        <IconUserCheck size={13} />
                        {release[field.reviewerField]?.displayName}
                      </span>
                    ) : (
                      <span
                        key={field.name}
                        className="flex items-center gap-1 text-yellow-700 dark:text-yellow-200 text-xs truncate"
                        title={`${field.name}: Pending (${release[field.reviewerField]?.displayName})`}
                      >
                        <IconUserX size={13} />
                        {release[field.reviewerField]?.displayName}
                      </span>
                    ),
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </Main>
    </>
  );
}
