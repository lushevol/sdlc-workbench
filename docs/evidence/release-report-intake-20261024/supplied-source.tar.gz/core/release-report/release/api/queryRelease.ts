import { queryOptions } from "@tanstack/react-query";
import request from "graphql-request";
import { service } from "ratan-auth";
import { graphql } from "@/gql/gql";
import { getAdoTokenFromLocal } from "@/utils/local-credential";
import type { ReleaseReport } from "../data/interfaces";

export const releaseIdQueryOptions = (releaseId: string) => {
  return queryOptions({
    queryKey: ["release", { releaseId }],
    queryFn: async () => {
      const response = await service.get<ReleaseReport>(
        `/api/oct/release-report-api/${releaseId}`,
        {
          timeout: 3 * 60 * 1000, // 3 minutes
          headers: {
            adotoken: getAdoTokenFromLocal() || import.meta.env.VITE_ADO_TOKEN,
          },
        },
      );
      return response.data;
    },
    staleTime: 10_000,
  });
};

const releaseNoListWithVariablesQueryDocument = graphql(/* GraphQL */ `
  query ReleaseNoList($from: String!, $to: String!) {
    queryRatanReleaseIds(from: $from, to: $to)
  }
`);
export const releaseIdListQueryOptions = (from: string, to: string) => {
  return queryOptions({
    queryKey: ["releases", { from, to }],
    queryFn: async () => {
      return request(
        `${location.origin}/api/oct/graphql`,
        releaseNoListWithVariablesQueryDocument,
        {
          from,
          to,
        },
        {
          adotoken: getAdoTokenFromLocal() || import.meta.env.VITE_ADO_TOKEN,
        },
      );
    },
    staleTime: 10_000,
  });
};

const releaseWithVariablesQueryDocument = graphql(/* GraphQL */ `
  query Release($id: Int!) {
    adoRelease(id: $id) {
      id
      title
      state
      type
      areaPath
      iterationPath
      description
      assignedTo {
        displayName
        uniqueName
        userId
      }
      comments
      reason
      changeId
      testingtypeinscope
      closedDate
      securityChampionApproval
      securityChampionReviewer {
        displayName
        uniqueName
        userId
      }
      poReviewer {
        displayName
        uniqueName
        userId
      }
      poApproval
      tsoReviewer {
        displayName
        uniqueName
        userId
      }
      tsoApproval
      tsuoReviewer {
        displayName
        uniqueName
        userId
      }
      tsuoApproval
      deploymentComponents
      deploymentComponentsPretty {
        repo
        command
      }
      latestPipelineRuns {
        repo
        buildId
        buildUrl
      }
      descriptionofchangeincludingtechnicaldetails
      plannedReleaseDate
      actualReleaseDate
      volumeoftransactionsaffectedorcreatedbychange
      rationaleforNotdoingPerformanceTesting
      rationaleforNotdoingotherMandatoryTestTypes
      releasePTPerformedon
      releasePTPlanDocumentLink
      releasePTReportDocumentLink
      relatedWorkitems
      testedByWorkitems
      storiesLinked
      applicableSecurityControls
      releaseApproach
      natureoftheChange
    }
  }
`);

export const releaseQueryOptions = (releaseId: number) => {
  return queryOptions({
    queryKey: ["release", { releaseId }],
    queryFn: async () => {
      return request(
        `${location.origin}/api/oct/graphql`,
        releaseWithVariablesQueryDocument,
        {
          id: releaseId,
        },
        {
          adotoken: getAdoTokenFromLocal() || import.meta.env.VITE_ADO_TOKEN,
        },
      );
    },
    staleTime: 10_000,
  });
};
