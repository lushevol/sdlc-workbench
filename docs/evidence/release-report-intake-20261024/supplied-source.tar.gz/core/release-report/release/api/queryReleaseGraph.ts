import { queryOptions } from "@tanstack/react-query";
import { service } from "ratan-auth";
import { getAdoTokenFromLocal } from "@/utils/local-credential";
import type { ReleaseGraphResponse } from "../data/release-graph";

export const releaseGraphQueryOptions = (releaseId: string) => {
  return queryOptions({
    queryKey: ["release-graph", { releaseId }],
    queryFn: async () => {
      const response = await service.get<ReleaseGraphResponse>(
        `/api/oct/release-graph-api/${releaseId}`,
        {
          timeout: 3 * 60 * 1000,
          headers: {
            adotoken: getAdoTokenFromLocal() || import.meta.env.VITE_ADO_TOKEN,
          },
        },
      );

      return response.data;
    },
    staleTime: 10_000,
    enabled: false,
  });
};