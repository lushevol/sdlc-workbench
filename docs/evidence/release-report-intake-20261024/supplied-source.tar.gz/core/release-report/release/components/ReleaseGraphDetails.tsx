import type { ReleaseGraphSelection } from "./release-graph-mapper";

interface ReleaseGraphDetailsProps {
  readonly selection: ReleaseGraphSelection | null;
}

function formatLineRangeLabel(startLine: number, endLine: number): string {
  return startLine === endLine
    ? `Line ${startLine}`
    : `Lines ${startLine}-${endLine}`;
}

export function ReleaseGraphDetails({
  selection,
}: ReleaseGraphDetailsProps) {
  if (!selection) {
    return (
      <div className="text-sm text-muted-foreground">
        Select a node to inspect release graph details.
      </div>
    );
  }

  if (selection.kind === "edge") {
    return (
      <div className="space-y-3 text-sm">
        <div>
          <div className="font-medium">Link Type</div>
          <div className="text-muted-foreground">{selection.edge.type}</div>
        </div>
        {selection.path && (
          <div>
            <div className="font-medium">Path</div>
            <div className="break-all text-muted-foreground">
              {selection.path}
            </div>
          </div>
        )}
        <div>
          <div className="font-medium">Changed Lines</div>
          {selection.lineRanges.length > 0 ? (
            <ul className="list-disc pl-5 text-muted-foreground">
              {selection.lineRanges.map((range) => (
                <li
                  key={`${range.startLine}-${range.endLine}`}
                >
                  {formatLineRangeLabel(range.startLine, range.endLine)}
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-muted-foreground">No line ranges available.</div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 text-sm">
      <div>
        <div className="font-medium">Type</div>
        <div className="text-muted-foreground">{selection.node.type}</div>
      </div>
      <div>
        <div className="font-medium">Label</div>
        <div className="text-muted-foreground">{selection.node.label}</div>
      </div>
      {"repo" in selection.node && selection.node.repo && (
        <div>
          <div className="font-medium">Repository</div>
          <div className="text-muted-foreground">{selection.node.repo}</div>
        </div>
      )}
      {"commitId" in selection.node && selection.node.commitId && (
        <div>
          <div className="font-medium">Commit</div>
          <div className="break-all text-muted-foreground">
            {selection.node.commitId}
          </div>
        </div>
      )}
      {"path" in selection.node && selection.node.path && (
        <div>
          <div className="font-medium">Path</div>
          <div className="break-all text-muted-foreground">
            {selection.node.path}
          </div>
        </div>
      )}
      {"storyId" in selection.node &&
        typeof selection.node.storyId === "number" && (
        <div>
          <div className="font-medium">Story ID</div>
          <div className="text-muted-foreground">{selection.node.storyId}</div>
        </div>
      )}
      {"testCaseId" in selection.node &&
        typeof selection.node.testCaseId === "number" && (
        <div>
          <div className="font-medium">Test Case ID</div>
          <div className="text-muted-foreground">{selection.node.testCaseId}</div>
        </div>
      )}
    </div>
  );
}