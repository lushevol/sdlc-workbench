import { lazy, Suspense, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { releaseGraphQueryOptions } from "../api/queryReleaseGraph";
import { ReleaseGraphDetails } from "./ReleaseGraphDetails";
import {
  mapReleaseGraphToECharts,
  type ReleaseGraphSelection,
} from "./release-graph-mapper";

const LazyReleaseGraphCanvas = lazy(async () => {
  const module = await import("./ReleaseGraphCanvas");

  return {
    default: module.ReleaseGraphCanvas,
  };
});

interface ReleaseGraphSectionProps {
  readonly releaseId: string;
}

function getErrorMessage(error: unknown): string {
  if (error instanceof Error && error.message) {
    return error.message;
  }

  return "Failed to load release graph.";
}

export function ReleaseGraphSection({
  releaseId,
}: ReleaseGraphSectionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasRequested, setHasRequested] = useState(false);
  const [selection, setSelection] = useState<ReleaseGraphSelection | null>(null);

  const query = useQuery({
    ...releaseGraphQueryOptions(releaseId),
    enabled: isOpen && hasRequested,
  });

  const mappedGraph = useMemo(() => {
    if (!query.data) {
      return null;
    }

    return mapReleaseGraphToECharts(query.data);
  }, [query.data]);

  function handleOpenChange(nextOpen: boolean) {
    setIsOpen(nextOpen);

    if (nextOpen) {
      setHasRequested(true);
      return;
    }

    setSelection(null);
  }

  const showLoadingState = (query.isLoading || query.isFetching) && !query.data;

  return (
    <section className="mb-6">
      <Collapsible open={isOpen} onOpenChange={handleOpenChange}>
        <Card>
          <CardHeader className="border-b">
            <div>
              <CardTitle>Release Graph</CardTitle>
              <CardDescription>
                Explore the repo, commit, story, and test-case relationships for this release.
              </CardDescription>
            </div>
            <CollapsibleTrigger asChild>
              <Button aria-expanded={isOpen} variant="outline">
                View Release Graph
              </Button>
            </CollapsibleTrigger>
          </CardHeader>
          <CollapsibleContent>
            <CardContent className="pt-6">
              {showLoadingState ? (
                <div className="text-sm text-muted-foreground">
                  Loading release graph...
                </div>
              ) : null}

              {!showLoadingState && query.error ? (
                <div className="space-y-3">
                  <div className="text-sm text-red-600">
                    Failed to load release graph.
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {getErrorMessage(query.error)}
                  </div>
                  <Button type="button" variant="outline" onClick={() => query.refetch()}>
                    Retry
                  </Button>
                </div>
              ) : null}

              {!showLoadingState && !query.error && mappedGraph ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-semibold">Release Graph Overview</h3>
                    <p className="text-sm text-muted-foreground">
                      Click a graph node or link to inspect changed files, line ranges, stories, and linked tests.
                    </p>
                  </div>
                  <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(320px,1fr)]">
                    <div className="rounded-lg border p-3">
                      <Suspense
                        fallback={
                          <div className="text-sm text-muted-foreground">
                            Loading release graph viewer...
                          </div>
                        }
                      >
                        <LazyReleaseGraphCanvas
                          graph={mappedGraph}
                          onSelect={setSelection}
                        />
                      </Suspense>
                    </div>
                    <div className="rounded-lg border p-4">
                      <ReleaseGraphDetails selection={selection} />
                    </div>
                  </div>
                </div>
              ) : null}

              {!showLoadingState && !query.error && !mappedGraph ? (
                <div className="text-sm text-muted-foreground">
                  No release graph data is available for this release.
                </div>
              ) : null}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </section>
  );
}