import ReactECharts from "echarts-for-react";
import type { ReleaseGraphEdge, ReleaseGraphNode } from "../data/release-graph";
import type {
  ReleaseGraphLineRange,
  ReleaseGraphMappedData,
  ReleaseGraphSelection,
} from "./release-graph-mapper";

interface ReleaseGraphCanvasProps {
  readonly graph: ReleaseGraphMappedData;
  readonly onSelect: (selection: ReleaseGraphSelection) => void;
}

function isReleaseGraphNode(value: unknown): value is ReleaseGraphNode {
  if (!value || typeof value !== "object") {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.id === "string" &&
    typeof candidate.type === "string" &&
    typeof candidate.label === "string"
  );
}

function isReleaseGraphEdge(value: unknown): value is ReleaseGraphEdge {
  if (!value || typeof value !== "object") {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.id === "string" &&
    typeof candidate.type === "string" &&
    typeof candidate.from === "string" &&
    typeof candidate.to === "string"
  );
}

function isLineRange(value: unknown): value is ReleaseGraphLineRange {
  if (!value || typeof value !== "object") {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.startLine === "number" &&
    typeof candidate.endLine === "number"
  );
}

function getLineRanges(value: unknown): ReleaseGraphLineRange[] {
  if (!value || typeof value !== "object") {
    return [];
  }

  const ranges = (value as Record<string, unknown>).lineRanges;

  if (!Array.isArray(ranges)) {
    return [];
  }

  return ranges.filter(isLineRange);
}

function getPath(value: unknown): string | undefined {
  if (!value || typeof value !== "object") {
    return undefined;
  }

  const path = (value as Record<string, unknown>).path;
  return typeof path === "string" ? path : undefined;
}

export function ReleaseGraphCanvas({
  graph,
  onSelect,
}: ReleaseGraphCanvasProps) {
  return (
    <ReactECharts
      style={{ height: "480px", width: "100%" }}
      option={{
        tooltip: {
          trigger: "item",
        },
        legend: [
          {
            data: graph.categories.map((category) => category.name),
            bottom: 0,
          },
        ],
        series: [
          {
            type: "graph",
            layout: "force",
            roam: true,
            draggable: false,
            label: {
              show: true,
              position: "right",
            },
            force: {
              repulsion: 260,
              edgeLength: 140,
            },
            lineStyle: {
              opacity: 0.7,
              width: 1.5,
              curveness: 0.08,
            },
            emphasis: {
              focus: "adjacency",
            },
            data: graph.nodes,
            links: graph.links,
            categories: graph.categories,
          },
        ],
      }}
      onEvents={{
        click: (params: { readonly dataType?: string; readonly data?: unknown }) => {
          if (params.dataType === "node" && isReleaseGraphNode((params.data as Record<string, unknown> | undefined)?.raw)) {
            onSelect({
              kind: "node",
              node: (params.data as Record<string, unknown>).raw as ReleaseGraphNode,
            });
          }

          if (params.dataType === "edge" && isReleaseGraphEdge((params.data as Record<string, unknown> | undefined)?.raw)) {
            const edgeData = params.data as Record<string, unknown>;

            onSelect({
              kind: "edge",
              edge: edgeData.raw as ReleaseGraphEdge,
              path: getPath(edgeData),
              lineRanges: getLineRanges(edgeData),
            });
          }
        },
      }}
    />
  );
}