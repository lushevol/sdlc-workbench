import type * as React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import ReleaseDetails from "../details";
import type { ReleaseGraphResponse } from "../data/release-graph";
import { ReleaseGraphSection } from "./ReleaseGraphSection";
import { ReleaseGraphDetails } from "./ReleaseGraphDetails";
import { mapReleaseGraphToECharts } from "./release-graph-mapper";
import { releaseGraphQueryOptions } from "../api/queryReleaseGraph";

const {
  getMock,
  getAdoTokenFromLocalMock,
  useQueryMock,
  routeUseParamsMock,
  graphRefetchMock,
  releaseRefetchMock,
} = vi.hoisted(() => ({
  getMock: vi.fn(),
  getAdoTokenFromLocalMock: vi.fn(),
  useQueryMock: vi.fn(),
  routeUseParamsMock: vi.fn(),
  graphRefetchMock: vi.fn(),
  releaseRefetchMock: vi.fn(),
}));

function setReleaseGraphEntryFlag(enabled: boolean) {
  vi.stubEnv(
    "VITE_ENABLE_RELEASE_GRAPH_ENTRY",
    enabled ? "true" : "false",
  );
}

vi.mock("echarts-for-react", () => ({
  default: ({
    onEvents,
  }: {
    readonly onEvents?: {
      readonly click?: (params: {
        readonly dataType?: string;
        readonly data?: unknown;
      }) => void;
    };
  }) => (
    <div>
      <button
        type="button"
        onClick={() =>
          onEvents?.click?.({
            dataType: "node",
            data: {
              raw: {
                id: "commit:a",
                type: "commit",
                label: "commit-a",
                repo: "repo-a",
                commitId: "abc123",
              },
            },
          })
        }
      >
        Select Commit
      </button>
      <button
        type="button"
        onClick={() =>
          onEvents?.click?.({
            dataType: "edge",
            data: {
              raw: {
                id: "edge-1",
                type: "commit_to_file",
                from: "commit:a",
                to: "file:a:x",
              },
              path: "/src/x.ts",
              lineRanges: [{ startLine: 10, endLine: 14 }],
            },
          })
        }
      >
        Select Changed File
      </button>
    </div>
  ),
}));

vi.mock("@tanstack/react-query", async () => {
  const actual = await vi.importActual<typeof import("@tanstack/react-query")>(
    "@tanstack/react-query",
  );

  return {
    ...actual,
    useQuery: useQueryMock,
  };
});

vi.mock("ratan-auth", () => ({
  service: {
    get: getMock,
  },
}));

vi.mock("@/utils/local-credential", () => ({
  getAdoTokenFromLocal: getAdoTokenFromLocalMock,
}));

vi.mock("@/components/layout/header", () => ({
  Header: ({ children }: { readonly children?: React.ReactNode }) => (
    <div>{children}</div>
  ),
}));

vi.mock("@/components/layout/main", () => ({
  Main: ({ children }: { readonly children?: React.ReactNode }) => (
    <main>{children}</main>
  ),
}));

vi.mock("@/components/profile-dropdown", () => ({
  ProfileDropdown: () => <div>Profile</div>,
}));

vi.mock("@/components/search", () => ({
  Search: () => <div>Search</div>,
}));

vi.mock("@/components/theme-switch", () => ({
  ThemeSwitch: () => <div>Theme</div>,
}));

vi.mock("@/components/ui/separator", () => ({
  Separator: () => <hr />,
}));

vi.mock("@/routes/_authenticated/release/$releaseId", () => ({
  Route: {
    useParams: routeUseParamsMock,
  },
}));

vi.mock("./BuildDiffStatus", () => ({
  BuildDiffStatus: () => <div>Build diff</div>,
}));

vi.mock("./ReleaseComplianceAudit", () => ({
  ReleaseComplianceAudit: () => <div>Compliance</div>,
}));

const sampleGraphResponse: ReleaseGraphResponse = {
  release: "123",
  nodes: [
    {
      id: "repo:repo-a",
      label: "repo-a",
      type: "repo",
      repo: "repo-a",
    },
    {
      id: "commit:a",
      label: "commit-a",
      type: "commit",
      repo: "repo-a",
      commitId: "abc123",
    },
    {
      id: "file:a:x",
      label: "/src/x.ts",
      type: "file",
      repo: "repo-a",
      commitId: "abc123",
      path: "/src/x.ts",
    },
  ],
  edges: [
    {
      id: "edge-1",
      type: "commit_to_file",
      from: "commit:a",
      to: "file:a:x",
      metadata: {
        path: "/src/x.ts",
        lineRanges: [{ startLine: 10, endLine: 14 }],
      },
    },
  ],
  meta: {
    counts: {
      repos: 1,
      commits: 1,
      files: 1,
      stories: 0,
      testCases: 0,
      edges: 1,
    },
    warnings: [],
    unresolvedStoryIds: [],
    unlinkedCommits: [],
  },
};

const releaseDetailsData = {
  release: {
    id: 123,
    title: "Release 123",
    plannedReleaseDate: "2026-07-30",
    state: "Ready",
    releaseApproach: "Controlled",
    natureoftheChange: "Standard",
  },
  compliance: undefined,
  builds: [],
  workitems: [],
};

const releaseDetailsWithoutCoverageData = {
  ...releaseDetailsData,
  builds: [
    {
      id: 456,
      repo: "oct-repo",
      url: "https://example.test/build/456",
      status: "completed",
      buildNumber: "456",
      result: "succeeded",
      startTime: "2026-07-30T10:00:00Z",
      finishTime: "2026-07-30T10:05:00Z",
      sourceBranch: "feature/my-change",
      sourceVersion: "abc123",
      diffs: {
        diffWithLatestCommit: {},
        diffWithReleasedProd: {},
        diffWithMainBranch: null,
        mainDiffWithProd: null,
        behindMainAllMergeCommit: false,
        behindProdAllMergeCommit: false,
        mainBehindProdAllMergeCommit: false,
        latestBranchCommit: "abc123",
        mainBranchCommit: null,
        prodCommit: "prod123",
        prodBranch: "main",
      },
      measures: undefined,
      prodMeasures: undefined,
    },
  ],
};

function configureUseQueryMock(graphState?: {
  data?: ReleaseGraphResponse;
  isLoading?: boolean;
  isFetching?: boolean;
  error?: Error | null;
}) {
  useQueryMock.mockImplementation(
    (options: { readonly queryKey: readonly unknown[]; readonly enabled?: boolean }) => {
      if (options.queryKey[0] === "release-graph") {
        return {
          data: graphState?.data,
          isLoading: graphState?.isLoading ?? false,
          isFetching: graphState?.isFetching ?? false,
          error: graphState?.error ?? null,
          refetch: graphRefetchMock,
        };
      }

      return {
        data: releaseDetailsData,
        isLoading: false,
        isRefetching: false,
        isFetching: false,
        error: null,
        refetch: releaseRefetchMock,
      };
    },
  );
}

function getReleaseGraphQueryCalls() {
  return useQueryMock.mock.calls
    .map(([options]) => options as { readonly queryKey: readonly unknown[]; readonly enabled?: boolean })
    .filter((options) => options.queryKey[0] === "release-graph");
}

beforeEach(() => {
  getMock.mockReset();
  getAdoTokenFromLocalMock.mockReset();
  useQueryMock.mockReset();
  routeUseParamsMock.mockReset();
  graphRefetchMock.mockReset();
  releaseRefetchMock.mockReset();
  routeUseParamsMock.mockReturnValue({ releaseId: "123" });
  configureUseQueryMock({ data: sampleGraphResponse });
  setReleaseGraphEntryFlag(false);
});

describe("releaseGraphQueryOptions", () => {
  it("uses the release graph query contract and token fallback", async () => {
    const releaseId = "12345";
    const responseData = { nodes: [], edges: [] };

    getAdoTokenFromLocalMock.mockReturnValue("local-ado-token");
    getMock.mockResolvedValue({ data: responseData });

    const query = releaseGraphQueryOptions(releaseId);

    expect(query.queryKey).toEqual(["release-graph", { releaseId }]);
    expect(query.staleTime).toBe(10_000);
    expect(query.enabled).toBe(false);
    expect(query.queryFn).toBeTypeOf("function");

    await expect(
      query.queryFn?.({
        client: {} as never,
        queryKey: query.queryKey,
        meta: undefined,
        signal: new AbortController().signal,
      }),
    ).resolves.toEqual(responseData);
    expect(getMock).toHaveBeenCalledWith(
      `/api/oct/release-graph-api/${releaseId}`,
      {
        timeout: 3 * 60 * 1000,
        headers: {
          adotoken: "local-ado-token",
        },
      },
    );
  });
});

describe("mapReleaseGraphToECharts", () => {
  it("maps commit_to_file metadata into selectable graph link data", () => {
    const mapped = mapReleaseGraphToECharts({
      release: "123",
      nodes: [
        {
          id: "commit:a",
          type: "commit",
          label: "commit-a",
          repo: "repo-a",
          commitId: "a",
        },
        {
          id: "file:a:x",
          type: "file",
          label: "/src/x.ts",
          repo: "repo-a",
          commitId: "a",
          path: "/src/x.ts",
        },
      ],
      edges: [
        {
          id: "edge-1",
          type: "commit_to_file",
          from: "commit:a",
          to: "file:a:x",
          metadata: {
            path: "/src/x.ts",
            lineRanges: [{ startLine: 10, endLine: 14 }],
          },
        },
      ],
      meta: {
        counts: {
          repos: 0,
          commits: 1,
          files: 1,
          stories: 0,
          testCases: 0,
          edges: 1,
        },
        warnings: [],
        unresolvedStoryIds: [],
        unlinkedCommits: [],
      },
    });

    expect(mapped.links[0]).toEqual(
      expect.objectContaining({
        source: "commit:a",
        target: "file:a:x",
        lineRanges: [{ startLine: 10, endLine: 14 }],
      }),
    );
  });
});

describe("ReleaseGraphDetails", () => {
  it("shows an empty selection message before a graph item is picked", () => {
    render(<ReleaseGraphDetails selection={null} />);

    expect(
      screen.getByText("Select a node to inspect release graph details."),
    ).toBeTruthy();
  });
});

describe("ReleaseGraphSection", () => {
  it("does not fetch the release graph before the user clicks", () => {
    render(<ReleaseGraphSection releaseId="123" />);

    expect(screen.queryByText(/loading release graph/i)).toBeNull();
    expect(getMock).not.toHaveBeenCalled();
    expect(getReleaseGraphQueryCalls()).toHaveLength(1);
    expect(getReleaseGraphQueryCalls()[0]?.enabled).toBe(false);
  });

  it("fetches and renders the graph after the user clicks the trigger", async () => {
    const user = userEvent.setup();

    render(<ReleaseGraphSection releaseId="123" />);

    await user.click(
      screen.getByRole("button", { name: /view release graph/i }),
    );

    expect(getReleaseGraphQueryCalls().at(-1)?.enabled).toBe(true);
    expect(screen.getByText(/release graph overview/i)).toBeTruthy();
    expect(
      await screen.findByRole("button", { name: /select commit/i }),
    ).toBeTruthy();
  });

  it("stops the release graph query when the panel is collapsed again", async () => {
    const user = userEvent.setup();

    render(<ReleaseGraphSection releaseId="123" />);

    const trigger = screen.getByRole("button", { name: /view release graph/i });

    await user.click(trigger);
    await user.click(trigger);

    expect(getReleaseGraphQueryCalls().at(-1)?.enabled).toBe(false);
  });

  it("shows retry controls when the release graph query fails", async () => {
    const user = userEvent.setup();

    configureUseQueryMock({ error: new Error("boom") });

    render(<ReleaseGraphSection releaseId="123" />);

    await user.click(
      screen.getByRole("button", { name: /view release graph/i }),
    );

    expect(screen.getByText(/failed to load release graph/i)).toBeTruthy();

    await user.click(screen.getByRole("button", { name: /retry/i }));

    expect(graphRefetchMock).toHaveBeenCalledTimes(1);
  });

  it("updates the detail panel when a graph node is selected", async () => {
    const user = userEvent.setup();

    render(<ReleaseGraphSection releaseId="123" />);

    await user.click(
      screen.getByRole("button", { name: /view release graph/i }),
    );
    await user.click(
      await screen.findByRole("button", { name: /select commit/i }),
    );

    expect(screen.getByText("abc123")).toBeTruthy();
  });

  it("shows file path and line ranges when a graph edge is selected", async () => {
    const user = userEvent.setup();

    render(<ReleaseGraphSection releaseId="123" />);

    await user.click(
      screen.getByRole("button", { name: /view release graph/i }),
    );
    await user.click(
      await screen.findByRole("button", { name: /select changed file/i }),
    );

    expect(screen.getByText("/src/x.ts")).toBeTruthy();
    expect(screen.getByText("Lines 10-14")).toBeTruthy();
  });
});

describe("ReleaseDetails", () => {
  it("does not render a release graph trigger when the feature flag is off", () => {
    render(<ReleaseDetails />);

    expect(
      screen.queryByRole("button", { name: /view release graph/i }),
    ).toBeNull();
  });

  it("renders a release graph trigger inside the release details page when the feature flag is on", () => {
    setReleaseGraphEntryFlag(true);

    render(<ReleaseDetails />);

    expect(
      screen.getByRole("button", { name: /view release graph/i }),
    ).toBeTruthy();
  });

  it("does not render the coverage cards when current coverage is missing", () => {
    useQueryMock.mockImplementation(
      (options: { readonly queryKey: readonly unknown[]; readonly enabled?: boolean }) => {
        if (options.queryKey[0] === "release-graph") {
          return {
            data: sampleGraphResponse,
            isLoading: false,
            isFetching: false,
            error: null,
            refetch: graphRefetchMock,
          };
        }

        return {
          data: releaseDetailsWithoutCoverageData,
          isLoading: false,
          isRefetching: false,
          isFetching: false,
          error: null,
          refetch: releaseRefetchMock,
        };
      },
    );

    render(<ReleaseDetails />);

    expect(screen.queryByText("ADO Line Coverage")).toBeNull();
    expect(screen.queryByText("ADO Branch Coverage")).toBeNull();
  });
});