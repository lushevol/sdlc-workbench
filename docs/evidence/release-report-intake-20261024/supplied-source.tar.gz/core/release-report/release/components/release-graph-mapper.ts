import type {
  ReleaseGraphEdge,
  ReleaseGraphNode,
  ReleaseGraphResponse,
} from "../data/release-graph";

type ReleaseGraphCategory = "repo" | "commit" | "file" | "story" | "testCase";

export interface ReleaseGraphLineRange {
  startLine: number;
  endLine: number;
}

export interface ReleaseGraphMappedNode {
  id: string;
  name: string;
  category: number;
  raw: ReleaseGraphNode;
}

export interface ReleaseGraphMappedLink {
  id: string;
  source: string;
  target: string;
  type: string;
  path?: string;
  lineRanges: ReleaseGraphLineRange[];
  raw: ReleaseGraphEdge;
}

export interface ReleaseGraphMappedData {
  categories: Array<{ name: ReleaseGraphCategory }>;
  nodes: ReleaseGraphMappedNode[];
  links: ReleaseGraphMappedLink[];
}

export type ReleaseGraphSelection =
  | {
      kind: "node";
      node: ReleaseGraphNode;
    }
  | {
      kind: "edge";
      edge: ReleaseGraphEdge;
      path?: string;
      lineRanges: ReleaseGraphLineRange[];
    };

const CATEGORY_INDEX: Record<ReleaseGraphCategory, number> = {
  repo: 0,
  commit: 1,
  file: 2,
  story: 3,
  testCase: 4,
};

function isLineRange(value: unknown): value is ReleaseGraphLineRange {
  if (!value || typeof value !== "object") {
    return false;
  }

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.startLine === "number" &&
    typeof candidate.endLine === "number"
  );
}

function getLineRanges(edge: ReleaseGraphEdge): ReleaseGraphLineRange[] {
  const ranges = edge.metadata?.lineRanges;

  if (!Array.isArray(ranges)) {
    return [];
  }

  return ranges.filter(isLineRange);
}

function getPath(edge: ReleaseGraphEdge): string | undefined {
  return typeof edge.metadata?.path === "string" ? edge.metadata.path : undefined;
}

export function mapReleaseGraphToECharts(
  graph: ReleaseGraphResponse,
): ReleaseGraphMappedData {
  return {
    categories: [
      { name: "repo" },
      { name: "commit" },
      { name: "file" },
      { name: "story" },
      { name: "testCase" },
    ],
    nodes: graph.nodes.map((node) => ({
      id: node.id,
      name: node.label,
      category: CATEGORY_INDEX[node.type],
      raw: node,
    })),
    links: graph.edges.map((edge) => ({
      id: edge.id,
      source: edge.from,
      target: edge.to,
      type: edge.type,
      path: getPath(edge),
      lineRanges: getLineRanges(edge),
      raw: edge,
    })),
  };
}