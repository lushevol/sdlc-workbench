import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

type GitCommitDiffs = {
  aheadCount?: number;
  allChangesIncluded?: boolean;
  baseCommit?: string;
  behindCount?: number;
  changeCounts?: {
    [key: number]: number;
  };
  commonCommit?: string;
  targetCommit?: string;
};

type BuildDiffs = {
  diffWithLatestCommit: GitCommitDiffs;
  diffWithReleasedProd: GitCommitDiffs;
  diffWithMainBranch: GitCommitDiffs | null;
  mainDiffWithProd: GitCommitDiffs | null;
  behindMainAllMergeCommit: boolean | null;
  behindProdAllMergeCommit: boolean | null;
  mainBehindProdAllMergeCommit: boolean | null;
  latestBranchCommit: string;
  mainBranchCommit: string | null;
  prodCommit: string;
  prodBranch: string;
};

const passedStatus = {
  PROD: "Branch not behind PROD",
  "Main Branch": "Branch not behind main",
  "Latest Commit": "Branch is at the latest commit",
  "PROD <-> main": "Main branch is sync with PROD",
};

function getDiffStatus(diffs: BuildDiffs, branch: string) {
  const res = Object.keys(passedStatus).reduce(
    (acc, key) => {
      acc[key as keyof typeof passedStatus] = {
        type: "ignore",
        message: null,
      };
      return acc;
    },
    {} as Record<
      keyof typeof passedStatus,
      { type: "issue" | "success" | "ignore"; message: string | null }
    >,
  );
  // Latest commit check
  if (
    Number(diffs.diffWithLatestCommit?.aheadCount) !== 0 ||
    Number(diffs.diffWithLatestCommit?.behindCount) !== 0
  ) {
    res["Latest Commit"] = {
      type: "issue",
      message: `Not the latest. (ahead: ${diffs.diffWithLatestCommit.aheadCount}, behind: ${diffs.diffWithLatestCommit.behindCount})`,
    };
  } else {
    res["Latest Commit"] = {
      type: "success",
      message: passedStatus["Latest Commit"],
    };
  }

  // Compare with main branch
  if (diffs.diffWithMainBranch === null) {
    // If no main branch, ignore the check
    res["Main Branch"] = {
      type: "ignore",
      message: null,
    };
  } else if (
    Number(diffs.diffWithMainBranch?.behindCount) > 0 &&
    diffs.behindMainAllMergeCommit !== true
  ) {
    res["Main Branch"] = {
      type: "issue",
      message: `Behind main by ${diffs.diffWithMainBranch?.behindCount} commit(s). (ahead: ${diffs.diffWithMainBranch?.aheadCount}, behind: ${diffs.diffWithMainBranch?.behindCount})`,
    };
  } else {
    res["Main Branch"] = {
      type: "success",
      message: passedStatus["Main Branch"],
    };
  }

  // PROD branch check
  if (branch === "main") {
    if (
      Number(Object.keys(diffs.mainDiffWithProd?.changeCounts ?? {}).length) > 0
    ) {
      res["PROD"] = {
        type: "issue",
        message: `Main branch is not sync with PROD. (ahead: ${diffs.mainDiffWithProd?.aheadCount}, behind: ${diffs.mainDiffWithProd?.behindCount})`,
      };
    } else {
      res["PROD"] = {
        type: "success",
        message: "Main branch is sync with PROD",
      };
    }
  } else if (
    Number(diffs.diffWithReleasedProd?.behindCount) > 0 &&
    diffs.behindProdAllMergeCommit !== true
  ) {
    res["PROD"] = {
      type: "issue",
      message: `Behind PROD by ${diffs.diffWithReleasedProd.behindCount} commit(s). (ahead: ${diffs.diffWithReleasedProd.aheadCount}, behind: ${diffs.diffWithReleasedProd.behindCount})`,
    };
  } else {
    res["PROD"] = {
      type: "success",
      message: passedStatus["PROD"],
    };
  }

  // Compare main and PROD
  if (diffs.mainDiffWithProd === null) {
    // If no main branch, ignore the check
    res["PROD <-> main"] = {
      type: "ignore",
      message: null,
    };
  } else if (
    Number(Object.keys(diffs.mainDiffWithProd?.changeCounts ?? {}).length) >
      0 &&
    diffs.mainBehindProdAllMergeCommit !== true
  ) {
    res["PROD <-> main"] = {
      type: "issue",
      message: `PROD branch is not sync with Main. (ahead: ${diffs.mainDiffWithProd?.aheadCount}, behind: ${diffs.mainDiffWithProd?.behindCount})`,
    };
  } else {
    res["PROD <-> main"] = {
      type: "success",
      message: passedStatus["PROD <-> main"],
    };
  }
  return res;
}

export const BuildDiffStatus = ({
  diffs,
  branch,
}: {
  diffs: BuildDiffs;
  branch: string;
}) => {
  const issues = getDiffStatus(diffs, branch);
  const issueCount = Object.values(issues).filter(
    (i) => i.type === "issue",
  ).length;

  function getRowStatus(label: keyof typeof passedStatus) {
    const found = issues[label];
    switch (found.type) {
      case "issue":
        return {
          icon: (
            <AlertCircle
              className="text-red-600 w-4 h-4 mr-1"
              aria-label="Issue"
            />
          ),
          msg: <span className="text-xs text-red-600">{found.message}</span>,
        };

      case "success":
        return {
          icon: (
            <CheckCircle2
              className="text-green-600 w-4 h-4 mr-1"
              aria-label="Pass"
            />
          ),
          msg: <span className="text-xs text-green-600">{found.message}</span>,
        };
      case "ignore":
        return {
          icon: (
            <CheckCircle2
              className="text-gray-400 w-4 h-4 mr-1"
              aria-label="No Check"
            />
          ),
          msg: <span className="text-xs text-gray-400">No check</span>,
        };

      default:
        return {
          icon: null,
          msg: null,
        };
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <span className="cursor-pointer inline-flex items-center">
          {issueCount > 0 ? (
            <>
              <Badge
                variant="destructive"
                className="ml-1 px-2 py-0 text-xs w-4 h-4"
              >
                {issueCount}
              </Badge>
            </>
          ) : (
            <CheckCircle2 className="text-green-600 w-4 h-4" />
          )}
        </span>
      </PopoverTrigger>
      <PopoverContent className="w-110 p-3">
        <div className="space-y-2">
          {Object.keys(passedStatus).map((key) => {
            const { icon, msg } = getRowStatus(
              key as keyof typeof passedStatus,
            );
            return (
              <Popover>
                <PopoverTrigger asChild>
                  <div
                    key={key}
                    className="flex items-center gap-2 cursor-pointer"
                  >
                    <span className="font-medium text-xs w-24">{key}</span>
                    {icon}
                    {msg}
                  </div>
                </PopoverTrigger>
                <PopoverContent className="w-120 p-2">
                  {key === "PROD" && (
                    <span className="text-xs text-gray-500 ml-2">
                      PROD Branch:{" "}
                      <span className="font-mono">{diffs.prodBranch}</span>
                      <br />
                      PROD Commit:{" "}
                      <span className="font-mono">{diffs.prodCommit}</span>
                    </span>
                  )}
                  {key === "Latest Commit" && (
                    <span className="text-xs text-gray-500 ml-2">
                      Branch Latest Commit:{" "}
                      <span className="font-mono">
                        {diffs.latestBranchCommit}
                      </span>
                    </span>
                  )}
                  {key === "Main Branch" && diffs.mainBranchCommit && (
                    <span className="text-xs text-gray-500 ml-2">
                      Main Branch Commit:{" "}
                      <span className="font-mono">
                        {diffs.mainBranchCommit}
                      </span>
                    </span>
                  )}
                </PopoverContent>
              </Popover>
            );
          })}
        </div>
        <div className="mt-4 border-t pt-2 text-xs text-gray-500">
          <strong>Idea Branch Model:</strong> <br />
          {branch === "main" ? (
            <span>
              <span className="font-mono">PROD</span> &lt;{" "}
              <span className="font-mono">main branch</span>
            </span>
          ) : (
            <span>
              <span className="font-mono">PROD</span> ={" "}
              <span className="font-mono">main</span> &lt;{" "}
              <span className="font-mono">release branch</span> ={" "}
              <span className="font-mono">latest commit</span>
            </span>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
