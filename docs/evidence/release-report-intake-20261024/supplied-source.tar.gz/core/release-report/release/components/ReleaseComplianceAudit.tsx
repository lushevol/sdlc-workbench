import { ChevronDownIcon } from "lucide-react";
import {
  buildAuditOverview,
  getAuditStatusClasses,
  getComplianceStatusClasses,
} from "../data/compliance-audit";
import type { ReleaseReport } from "../data/interfaces";

type ReleaseComplianceAuditProps = Readonly<{
  release: ReleaseReport["release"] | undefined;
  compliance: ReleaseReport["compliance"] | null | undefined;
}>;

export function ReleaseComplianceAudit({
  release,
  compliance,
}: ReleaseComplianceAuditProps) {
  if (!release || !compliance) {
    return (
      <section className="mb-6">
        <h2 className="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">
          Release Compliance
        </h2>
        <div className="rounded-lg border border-gray-200 bg-white/80 p-4 shadow-sm dark:bg-gray-800 dark:border-gray-700">
          <div className="text-xs text-gray-500 dark:text-gray-300">
            Compliance assessment unavailable for this release.
          </div>
        </div>
      </section>
    );
  }

  const audit = buildAuditOverview(release, compliance);

  return (
    <section className="mb-6">
      <h2 className="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">
        Release Compliance
      </h2>
      <div className="rounded-lg border border-gray-200 bg-white/80 p-4 shadow-sm dark:bg-gray-800 dark:border-gray-700">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
            <div>
              <div className="text-xs text-gray-500 dark:text-gray-300">
                Overall Status
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-3">
                <span
                  className={`rounded px-2 py-1 text-xs font-semibold ${getComplianceStatusClasses(
                    audit.overallStatus,
                  )}`}
                >
                  {audit.overallStatus}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-3 text-xs">
              <div className="rounded border border-red-200 bg-red-50 px-3 py-2 text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">
                <div className="font-semibold">Critical</div>
                <div>{audit.summary.critical}</div>
              </div>
              <div className="rounded border border-red-200 bg-red-50 px-3 py-2 text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">
                <div className="font-semibold">Fails</div>
                <div>{audit.summary.fail}</div>
              </div>
              <div className="rounded border border-yellow-200 bg-yellow-50 px-3 py-2 text-yellow-700 dark:border-yellow-900 dark:bg-yellow-950/40 dark:text-yellow-300">
                <div className="font-semibold">Warnings</div>
                <div>{audit.summary.warn}</div>
              </div>
              <div className="rounded border border-green-200 bg-green-50 px-3 py-2 text-green-700 dark:border-green-900 dark:bg-green-950/40 dark:text-green-300">
                <div className="font-semibold">Pass</div>
                <div>{audit.summary.pass}</div>
              </div>
            </div>
          </div>

          <div className="grid gap-3 [grid-template-columns:repeat(auto-fit,minmax(16rem,1fr))]">
            {audit.cards.map((card) => (
              <details
                key={card.key}
                className={`group rounded-lg border shadow-sm ${getAuditStatusClasses(
                  card.status,
                )}`}
              >
                <summary className="flex cursor-pointer list-none items-start justify-between gap-3 p-4">
                  <div>
                    <div className="text-sm font-semibold">{card.title}</div>
                    <div className="text-[11px] opacity-80">{card.gate}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-black/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide dark:bg-white/10">
                      {card.status}
                    </span>
                    {card.effectiveCritical ? (
                      <span className="rounded bg-black/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide dark:bg-white/10">
                        Critical
                      </span>
                    ) : null}
                    <ChevronDownIcon className="mt-0.5 size-4 shrink-0 opacity-70 transition-transform group-open:rotate-180" />
                  </div>
                </summary>
                <div className="border-t border-current/15 px-4 py-3 text-xs">
                  <div>{card.evidence}</div>
                  {card.gap ? (
                    <div className="mt-3 rounded border border-current/20 bg-white/40 px-3 py-2 text-xs dark:bg-black/10">
                      <div className="font-semibold">Gap</div>
                      <div>{card.gap}</div>
                    </div>
                  ) : null}
                  {card.guidance ? (
                    <div className="mt-3 rounded border border-current/20 bg-white/40 px-3 py-2 text-xs dark:bg-black/10">
                      <div className="font-semibold">How to fix</div>
                      <div>{card.guidance}</div>
                    </div>
                  ) : null}
                </div>
              </details>
            ))}
          </div>

          {audit.hiddenExtraCheckCount > 0 ? (
            <div>
              <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-200">
                Additional Compliance Signals
              </h3>
              <div className="rounded border border-gray-200 bg-gray-50 px-3 py-2 text-xs text-gray-600 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300">
                {audit.hiddenExtraCheckCount} additional compliance check(s) are
                contributing to the backend overall status but are not rendered
                as audit cards in this detail view.
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}
