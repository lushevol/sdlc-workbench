import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Main } from "@/components/layout/main";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { Search } from "@/components/search";
import { ThemeSwitch } from "@/components/theme-switch";
import { Separator } from "@/components/ui/separator";
import { Route } from "@/routes/_authenticated/release/$releaseId";
import { releaseIdQueryOptions } from "./api/queryRelease";
import { BuildDiffStatus } from "./components/BuildDiffStatus";
import { ReleaseComplianceAudit } from "./components/ReleaseComplianceAudit";
import { ReleaseGraphSection } from "./components/ReleaseGraphSection";

const NOT_DISPLAY_BUILD_LIST = [
  "51358-ratanone-ansible",
  "51358-ratanone-command",
  "51358-ratanone-db-repository",
  "51358-ratan-service-properties",
  "51358-ratanone-service",
];

function getRateColorClass(rate?: number): string {
  if (typeof rate !== "number") return "";
  if (rate < 80) return "text-red-600";
  if (rate >= 90) return "text-green-600";
  return "";
}

export default function ReleaseDetails() {
  const { releaseId } = Route.useParams();
  const isReleaseGraphEntryEnabled =
    import.meta.env.VITE_ENABLE_RELEASE_GRAPH_ENTRY === "true";
  const {
    data: releaseDetails,
    isLoading,
    isRefetching,
    refetch,
  } = useQuery(releaseIdQueryOptions(releaseId));

  const release = releaseDetails?.release;
  const compliance = releaseDetails?.compliance;
  const builds = releaseDetails?.builds ?? [];
  const workitems = releaseDetails?.workitems ?? [];

  return (
    <>
      <Header>
        <Search />
        <div className="ml-auto flex items-center gap-4">
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>
      <Main className="overflow-y-auto max-h-[calc(100vh-64px)] px-8 py-8 to-gray-50 bg-white dark:bg-gray-900">
        {isLoading && (
          <div className="flex items-center justify-center py-12">
            <span className="animate-spin rounded-full h-6 w-6 border-2 border-blue-500 border-t-transparent mr-3 dark:border-blue-400 dark:border-t-transparent" />
            <span className="text-sm text-gray-700 font-medium dark:text-gray-200">
              Loading release details...
            </span>
          </div>
        )}
        {isRefetching && (
          <div className="flex items-center justify-center py-2">
            <span className="animate-spin rounded-full h-4 w-4 border-2 border-blue-400 border-t-transparent mr-2 dark:border-blue-300 dark:border-t-transparent" />
            <span className="text-xs text-gray-500 font-medium dark:text-gray-300">
              Refreshing data...
            </span>
          </div>
        )}
        {/* Go Back & Refresh Buttons */}
        <div className="flex items-center gap-3 mb-6">
          <button
            type="button"
            className="shadcn-btn px-4 py-2 rounded-md bg-muted text-sm font-medium border border-input hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 dark:bg-gray-800 dark:text-gray-100 dark:border-gray-700"
            onClick={() =>
              window.history.length > 1
                ? window.history.back()
                : window.location.assign("/release/board")
            }
            aria-label="Go back"
          >
            ← Go Back
          </button>
          <button
            type="button"
            className="shadcn-btn px-4 py-2 rounded-md bg-primary text-white text-sm font-medium border border-primary hover:bg-primary/90 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20 dark:bg-blue-700 dark:border-blue-700 dark:hover:bg-blue-800"
            onClick={() => refetch()}
            aria-label="Refresh page"
            disabled={isLoading || isRefetching}
          >
            ⟳ Refresh
          </button>
        </div>
        {/* Header Section */}
        <section className="mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <h1 className="text-xl font-bold dark:text-gray-100">
              {release?.title ?? (
                <span
                  className="text-gray-400 dark:text-gray-500"
                  aria-live="polite"
                >
                  Loading...
                </span>
              )}
            </h1>
            <div className="flex gap-8">
              <div className="flex flex-col text-xs">
                <span className="opacity-80 dark:text-gray-300">
                  Release ID
                </span>
                <a
                  href={`https://dev.azure.com/sc-ado/FMQPR/_workitems/edit/${release?.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline text-blue-700 font-medium dark:text-blue-400"
                >
                  {release?.id ?? (
                    <span
                      className="text-gray-400 dark:text-gray-500"
                      aria-live="polite"
                    >
                      Loading...
                    </span>
                  )}
                </a>
              </div>
              <div className="flex flex-col text-xs">
                <span className="opacity-80 dark:text-gray-300">
                  Planned Date
                </span>
                <span className="font-medium dark:text-gray-100">
                  {release?.plannedReleaseDate ?? (
                    <span
                      className="text-gray-400 dark:text-gray-500"
                      aria-live="polite"
                    >
                      Loading...
                    </span>
                  )}
                </span>
              </div>
              <div className="flex flex-col text-xs">
                <span className="opacity-80 dark:text-gray-300">Status</span>
                <span className="font-medium dark:text-gray-100">
                  {release?.state ?? (
                    <span
                      className="text-gray-400 dark:text-gray-500"
                      aria-live="polite"
                    >
                      Loading...
                    </span>
                  )}
                </span>
              </div>
              <div className="flex flex-col text-xs">
                <span className="opacity-80 dark:text-gray-300">
                  Release Approach
                </span>
                <span className="font-medium dark:text-gray-100">
                  {release?.releaseApproach ?? (
                    <span
                      className="text-gray-400 dark:text-gray-500"
                      aria-live="polite"
                    >
                      Loading...
                    </span>
                  )}
                </span>
              </div>
              <div className="flex flex-col text-xs">
                <span className="opacity-80 dark:text-gray-300">
                  Nature of Change
                </span>
                <span className="font-medium dark:text-gray-100">
                  {release?.natureoftheChange ?? (
                    <span
                      className="text-gray-400 dark:text-gray-500"
                      aria-live="polite"
                    >
                      Loading...
                    </span>
                  )}
                </span>
              </div>
            </div>
          </div>
        </section>

        <ReleaseComplianceAudit release={release} compliance={compliance} />

        <Separator className="my-6 dark:bg-gray-700" />

        {/* Work Items */}
        <section className="mb-6">
          <h2 className="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">
            Work Items
          </h2>
          <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white/80 shadow-sm dark:bg-gray-800 dark:border-gray-700">
            <table className="min-w-full text-xs border-collapse">
              <thead>
                <tr>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    ID
                  </th>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    Title
                  </th>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    Type
                  </th>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    State
                  </th>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    Test Cases
                  </th>
                  <th
                    className="bg-gray-50 px-3 py-2 text-left font-semibold text-gray-700 dark:bg-gray-900 dark:text-gray-200"
                    scope="col"
                  >
                    Test Bugs
                  </th>
                </tr>
              </thead>
              <tbody>
                {workitems.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b last:border-b-0 dark:border-gray-700"
                  >
                    <td className="px-3 py-2">
                      <a
                        href={`https://dev.azure.com/sc-ado/FMQPR/_workitems/edit/${item.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline text-blue-700 font-medium dark:text-blue-400"
                      >
                        {item.id}
                      </a>
                    </td>
                    <td className="px-3 py-2 dark:text-gray-100">
                      {item.title}
                    </td>
                    <td className="px-3 py-2 dark:text-gray-100">
                      {item.type}
                    </td>
                    <td className="px-3 py-2 dark:text-gray-100">
                      {item.state}
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex gap-1 flex-wrap">
                        {item.testExecutionStatusStats?.countByType?.PASSED ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-green-600" />
                            Passed:{" "}
                            {item.testExecutionStatusStats.countByType.PASSED}
                          </span>
                        ) : null}
                        {item.testExecutionStatusStats?.countByType?.FAILED ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-red-600" />
                            Failed:{" "}
                            {item.testExecutionStatusStats.countByType.FAILED}
                          </span>
                        ) : null}
                        {item.testExecutionStatusStats?.countByType
                          ?.NO_EXECUTION ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-yellow-500" />
                            No Execution:{" "}
                            {
                              item.testExecutionStatusStats.countByType
                                .NO_EXECUTION
                            }
                          </span>
                        ) : null}
                        {item.testExecutionStatusStats?.countByType?.BLOCKED ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-yellow-500" />
                            Blocked:{" "}
                            {item.testExecutionStatusStats.countByType.BLOCKED}
                          </span>
                        ) : null}
                        {item.testExecutionStatusStats?.countByType
                          ?.DEFERRED ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-yellow-500" />
                            Deferred:{" "}
                            {item.testExecutionStatusStats.countByType.DEFERRED}
                          </span>
                        ) : null}
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex gap-1 flex-wrap">
                        {item.defectStatusStats?.countByType?.OPEN ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-red-600" />
                            Open: {item.defectStatusStats.countByType.OPEN}
                          </span>
                        ) : null}
                        {item.defectStatusStats?.countByType?.IN_PROGRESS ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-yellow-500" />
                            In Progress:{" "}
                            {item.defectStatusStats.countByType.IN_PROGRESS}
                          </span>
                        ) : null}
                        {item.defectStatusStats?.countByType?.CLOSED ? (
                          <span className="flex items-center gap-1 text-xs">
                            <span className="inline-block w-2 h-2 rounded-full bg-green-600" />
                            Closed: {item.defectStatusStats.countByType.CLOSED}
                          </span>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <Separator className="my-6 dark:bg-gray-700" />

        {isReleaseGraphEntryEnabled ? (
          <>
            <ReleaseGraphSection releaseId={releaseId} />

            <Separator className="my-6 dark:bg-gray-700" />
          </>
        ) : null}

        {/* Build Status */}
        <section>
          <h2 className="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">
            Build Status
          </h2>
          {isLoading ? (
            <span
              className="text-gray-400 dark:text-gray-500"
              aria-live="polite"
            >
              Loading...
            </span>
          ) : null}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...builds]
              .sort((a, b) => {
                const aInList = NOT_DISPLAY_BUILD_LIST.includes(a.repo);
                const bInList = NOT_DISPLAY_BUILD_LIST.includes(b.repo);
                if (aInList && !bInList) return 1;
                if (!aInList && bInList) return -1;
                return a.repo.localeCompare(b.repo);
              })
              .map((build) => (
                <div
                  key={build.repo}
                  className="rounded-lg border border-gray-200 bg-white/80 p-3 shadow-sm dark:bg-gray-800 dark:border-gray-700"
                >
                  <div className="flex flex-col md:flex-row md:justify-between mb-1 gap-2">
                    <div className="font-semibold text-gray-700 dark:text-gray-200">
                      <a
                        href={`https://dev.azure.com/sc-ado/FMQPR/_build/results?buildId=${build.id}&view=results`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline hover:text-blue-900 font-semibold dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        {build.repo}
                      </a>
                    </div>
                  </div>
                  <div className="mb-1 text-xs text-gray-500 dark:text-gray-300">
                    <div className="flex gap-4 flex-wrap">
                      <a
                        href={`https://dev.azure.com/sc-ado/FMQPR/_git/${build.repo}?version=GB${encodeURIComponent(build.sourceBranch ?? "")}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline hover:text-blue-900 font-semibold dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        Branch: {build.sourceBranch}
                      </a>
                      <BuildDiffStatus
                        diffs={build.diffs}
                        branch={build.sourceBranch}
                      />
                    </div>
                  </div>
                  {hasCurrentCoverage(build.measures) ? (
                    <div className="flex gap-2 flex-wrap">
                      {/* Line Coverage */}
                      <div
                        className={`bg-gray-50 rounded p-2 min-w-[80px] ${getRateColorClass(build.measures?.line_coverage)} dark:bg-gray-900`}
                      >
                        <div className="text-xs opacity-80 dark:text-gray-300">
                          ADO Line Coverage
                        </div>
                        <div className="font-semibold dark:text-gray-100 flex items-center">
                          <CoverageMetricLink
                            buildId={build.id}
                            metric={build.measures?.line_coverage}
                          />
                          <MetricDiffBadge
                            metric={build.measures?.line_coverage}
                            prodMetric={build.prodMeasures?.line_coverage}
                            type="coverage"
                          />
                        </div>
                      </div>
                      {/* Branch Coverage */}
                      <div
                        className={`bg-gray-50 rounded p-2 min-w-[80px] ${getRateColorClass(build.measures?.branch_coverage)} dark:bg-gray-900`}
                      >
                        <div className="text-xs opacity-80 dark:text-gray-300">
                          ADO Branch Coverage
                        </div>
                        <div className="font-semibold dark:text-gray-100 flex items-center">
                          <CoverageMetricLink
                            buildId={build.id}
                            metric={build.measures?.branch_coverage}
                          />
                          <MetricDiffBadge
                            metric={build.measures?.branch_coverage}
                            prodMetric={build.prodMeasures?.branch_coverage}
                            type="coverage"
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}
                </div>
              ))}
          </div>
        </section>
      </Main>
    </>
  );
}

function CoverageMetricLink({
  buildId,
  metric,
}: Readonly<{
  buildId: number;
  metric?: number;
}>) {
  if (typeof metric !== "number") {
    return <span className="text-gray-500 dark:text-gray-400">-</span>;
  }

  return (
    <a
      href={`https://dev.azure.com/sc-ado/FMQPR/_build/results?buildId=${buildId}&view=artifacts&type=publishedArtifacts`}
      target="_blank"
      rel="noopener noreferrer"
      title="View coverage artifact in Azure DevOps"
    >
      {metric}%
    </a>
  );
}

function hasCurrentCoverage(
  measures?: {
    line_coverage?: number;
    branch_coverage?: number;
  },
): boolean {
  return (
    typeof measures?.line_coverage === "number" ||
    typeof measures?.branch_coverage === "number"
  );
}

// Helper to compare and render badge
function MetricDiffBadge({
  metric,
  prodMetric,
  type,
}: {
  metric?: number;
  prodMetric?: number;
  type: "coverage";
}) {
  if (typeof metric !== "number" || typeof prodMetric !== "number") return null;
  if (metric === prodMetric) return null;
  const diff = Number((metric - prodMetric).toFixed(1));
  let isGreen = false;
  if (type === "coverage") {
    isGreen = diff > 0;
  } else {
    isGreen = diff < 0;
  }
  return (
    <span
      className={`ml-1 px-1 py-0.5 rounded text-xs font-semibold ${
        isGreen ? "bg-green-600 text-white" : "bg-red-600 text-white"
      }`}
      title={
        isGreen
          ? `${type === "coverage" ? "Increased" : "Decreased"} from ${prodMetric} to ${metric}`
          : `${type === "coverage" ? "Decreased" : "Increased"} from ${prodMetric} to ${metric}`
      }
    >
      {diff > 0 ? "+" : ""}
      {diff}
    </span>
  );
}
