import { Injectable, Logger } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import {
  AzureDevOps as adoClient,
  getNormalizedReleaseComplianceChecks,
  RELEASE_COMPLIANCE_GATE_LABELS,
  type TestReport,
} from "ratan-ado-api";
import type { ParsedMeasuresComponent } from "ratan-sonarqube-api";
import { DrizzleService } from "../drizzle/drizzle.service";
import {
  RELEASE_REPORT_FIELDS,
  type ReleaseReportField,
  type ReleaseReport,
  type ReleaseReportComplianceCheck,
} from "./interfaces";

type ReleaseReportTokens = {
  adotoken: string;
};

type AdoCoverageSummary = {
  lineCoverage: number;
  branchCoverage: number;
};

@Injectable()
export class ReleaseReportService {
  constructor(
    _drizzleService: DrizzleService,
    private readonly configService: ConfigService,
  ) {}

  private readonly logger = new Logger(ReleaseReportService.name, {
    timestamp: true,
  });

  async generateReleaseReport(
    releaseId: string,
    tokens?: Partial<ReleaseReportTokens>,
    include?: readonly ReleaseReportField[],
  ): Promise<ReleaseReport> {
    const includedFields = this.getIncludedFields(include);
    const shouldIncludeCompliance = includedFields.has("compliance");
    const shouldIncludeBuilds = includedFields.has("builds");
    const shouldIncludeWorkitems = includedFields.has("workitems");
    const resolvedTokens = this.resolveTokens(tokens);

    this.logger.log(`Generating release report for release ID: ${releaseId}`);
    const ado = new adoClient();
    await ado.connect(resolvedTokens.adotoken);

    this.logger.log(`Fetching details for release ID: ${releaseId}`);
    const [release] = await ado.getReleaseWorkItems([Number(releaseId)]);
    this.logger.log(
      `Release details fetched successfully for ID: ${releaseId}`,
    );
    if (!release) {
      this.logger.error(`Release with ID ${releaseId} not found`);
      throw new Error(`Release with ID ${releaseId} not found`);
    }

    const compliance = shouldIncludeCompliance
      ? await this.fetchCompliance(ado, releaseId)
      : undefined;
    const latestPipelineRuns = release.latestPipelineRuns.filter(
      (run): run is typeof run & { buildId: number } => Boolean(run.buildId),
    );
    let builds: ReleaseReport["builds"];
    if (shouldIncludeBuilds) {
      builds = await this.fetchBuilds(ado, latestPipelineRuns);
    }
    const testReports = shouldIncludeWorkitems
      ? await this.fetchTestReports(ado, latestPipelineRuns)
      : [];
    const workitems = shouldIncludeWorkitems
      ? await this.fetchWorkitems(
          ado,
          release.relatedWorkitems ?? [],
          testReports,
        )
      : undefined;

    const report: ReleaseReport = {
      release,
      ...(shouldIncludeCompliance ? { compliance } : {}),
      // releaseSummary,
      ...(shouldIncludeWorkitems ? { workitems } : {}),
      ...(shouldIncludeBuilds ? { builds } : {}),
    };

    this.logger.log(
      `Release report generated successfully for release ID: ${releaseId}`,
    );

    // this.drizzleService.upsertReleaseReportMemory({
    //   releaseId: Number(releaseId),
    //   report: JSON.stringify(report),
    // });

    return report;
  }

  private resolveTokens(
    tokens?: Partial<ReleaseReportTokens>,
  ): ReleaseReportTokens {
    const adotoken =
      tokens?.adotoken || this.configService.get<string>("ADO_TOKEN");
    if (!adotoken) {
      throw new Error("ADO token is required");
    }

    return { adotoken };
  }

  private getIncludedFields(
    include?: readonly ReleaseReportField[],
  ): Set<ReleaseReportField> {
    const fields = new Set<ReleaseReportField>();

    if (!include) {
      for (const field of RELEASE_REPORT_FIELDS) {
        fields.add(field);
      }

      return fields;
    }

    if (include.length === 0) {
      return fields;
    }

    for (const field of include) {
      fields.add(field);
    }

    return fields;
  }

  private async fetchCompliance(
    ado: adoClient,
    releaseId: string,
  ): Promise<ReleaseReport["compliance"]> {
    try {
      const assessment = await ado.getReleaseComplianceAssessment(
        Number(releaseId),
      );
      if (!assessment) {
        return null;
      }

      const normalizedChecks = getNormalizedReleaseComplianceChecks(
        assessment.checks,
        assessment.fields,
      );
      const checks: ReleaseReportComplianceCheck[] = Object.entries(
        normalizedChecks,
      ).map(([key, value]) => ({
        key: key as ReleaseReportComplianceCheck["key"],
        label:
          RELEASE_COMPLIANCE_GATE_LABELS[
            key as keyof typeof RELEASE_COMPLIANCE_GATE_LABELS
          ],
        status: value.status,
      }));

      return {
        overallStatus: assessment.overallStatus,
        checks,
        linkedStoryCount: assessment.linkedStories.length,
      };
    } catch (error) {
      this.logger.error(
        `Failed to fetch release compliance for ID: ${releaseId}`,
        error,
      );
      return null;
    }
  }

  private async fetchBuilds(
    ado: adoClient,
    latestPipelineRuns: Array<{ buildId: number }>,
  ): Promise<NonNullable<ReleaseReport["builds"]>> {
    const coverageAdo = ado as adoClient & {
      getCoverageSummaryByBuildId: (buildId: number) => Promise<unknown>;
      getCoverageSummaryByBranchName: (
        branchName: string,
        repoName: string,
      ) => Promise<unknown>;
    };

    const builds = await Promise.all(
      latestPipelineRuns.map(async (run) => {
        try {
          this.logger.log(`Fetching details for build: ${run.buildId}`);
          const { formattedBuild } = await ado.getBuildById(run.buildId);

          const diffs = await ado.getReleaseDiffChecking(
            formattedBuild.repo,
            formattedBuild.sourceBranch,
            formattedBuild.sourceVersion,
          );

          let measures: ParsedMeasuresComponent | undefined;
          if (shouldFetchCoverage(formattedBuild.sourceBranch)) {
            this.logger.log(
              `Fetching ADO coverage for build ${formattedBuild.id} on branch ${formattedBuild.sourceBranch} and repo ${formattedBuild.repo}`,
            );
            try {
              const coverage = parseCoverageSummary(
                await coverageAdo.getCoverageSummaryByBuildId(
                  formattedBuild.id,
                ),
              );
              if (coverage) {
                measures = {
                  coverage: coverage.lineCoverage,
                  line_coverage: coverage.lineCoverage,
                  branch_coverage: coverage.branchCoverage,
                } as ParsedMeasuresComponent;
              }
            } catch (error) {
              this.logger.error(
                `Error fetching ADO coverage for build ${formattedBuild.id}: ${getErrorMessage(error)}`,
                error,
              );
            }
          }

          let prodMeasures: ParsedMeasuresComponent | undefined;
          if (shouldFetchCoverage(formattedBuild.sourceBranch)) {
            try {
              const prodCoverage = parseCoverageSummary(
                await coverageAdo.getCoverageSummaryByBranchName(
                  diffs.prodBranch,
                  formattedBuild.repo,
                ),
              );
              if (prodCoverage) {
                prodMeasures = {
                  coverage: prodCoverage.lineCoverage,
                  line_coverage: prodCoverage.lineCoverage,
                  branch_coverage: prodCoverage.branchCoverage,
                } as ParsedMeasuresComponent;
              }
            } catch (error) {
              this.logger.error(
                `Error fetching ADO coverage for PROD branch ${diffs.prodBranch} for build ${formattedBuild.id} on repo ${formattedBuild.repo}: ${getErrorMessage(error)}`,
                error,
              );
            }
          }

          return {
            id: formattedBuild.id,
            url: formattedBuild.url,
            status: formattedBuild.status,
            repo: formattedBuild.repo,
            buildNumber: formattedBuild.buildNumber,
            result: formattedBuild.result,
            startTime: formattedBuild.startTime,
            finishTime: formattedBuild.finishTime,
            sourceBranch: formattedBuild.sourceBranch,
            sourceVersion: formattedBuild.sourceVersion,
            ...(measures ? { measures } : {}),
            ...(prodMeasures ? { prodMeasures } : {}),
            diffs,
          };
        } catch (error) {
          this.logger.error(
            `Failed to fetch details for build: ${run.buildId}`,
            error,
          );

          return null;
        }
      }),
    );

    const successfulBuilds: NonNullable<ReleaseReport["builds"]> = [];
    for (const build of builds) {
      if (build) {
        successfulBuilds.push(build);
      }
    }

    this.logger.log(`Builds details fetched successfully`);
    return successfulBuilds;
  }

  private async fetchTestReports(
    ado: adoClient,
    latestPipelineRuns: Array<{ buildId: number }>,
  ): Promise<TestReport[]> {
    const testReports = await Promise.all(
      latestPipelineRuns.map(async (run) => {
        try {
          this.logger.log(`Fetching test report for build ID: ${run.buildId}`);
          const testReportStr = await ado.getBuildAttachmentContent(
            run.buildId,
            "testreport",
          );
          return JSON.parse(testReportStr) as TestReport;
        } catch (error) {
          this.logger.error(
            `Failed to fetch test report for build ID: ${run.buildId}`,
            error,
          );

          return null;
        }
      }),
    );

    const successfulReports: TestReport[] = [];
    for (const report of testReports) {
      if (report) {
        successfulReports.push(report);
      }
    }

    this.logger.log(`Test reports fetched successfully`);
    return successfulReports;
  }

  private async fetchWorkitems(
    ado: adoClient,
    relatedWorkitemIds: number[],
    testReports: TestReport[],
  ): Promise<NonNullable<ReleaseReport["workitems"]>> {
    const workitemsWithType = await ado.getWorkitemsByFields(
      relatedWorkitemIds,
      ["System.WorkItemType", "System.Title"],
    );

    const stories = workitemsWithType.filter(
      (item) => item.fields?.["System.WorkItemType"] === "Story",
    );
    const tasks = workitemsWithType.filter(
      (item) => item.fields?.["System.WorkItemType"] === "Generic Task",
    );
    const bugs = workitemsWithType.filter(
      (item) => item.fields?.["System.WorkItemType"] === "Bug",
    );
    const subtasks = workitemsWithType.filter(
      (item) => item.fields?.["System.WorkItemType"] === "Subtask",
    );
    this.logger.log(`Related work items simple fetched successfully`);

    const ids = [...stories, ...tasks, ...bugs, ...subtasks]
      .map((item) => item.id)
      .filter((id): id is number => typeof id === "number");
    const relatedWorkitems = await ado.getCommonWorkItems(ids);
    this.logger.log(`Related work items details fetched successfully`);

    const requirementCoverages = testReports.flatMap(
      (report) => report.requirementCoverages,
    );

    return relatedWorkitems.map((item) => ({
      id: item.id,
      title: item.title,
      type: item.type,
      state: item.state,
      testExecutionStatusStats: requirementCoverages.find(
        (coverage) => Number(coverage.id) === item.id,
      )?.testExecutionStatusStats,
      defectStatusStats: requirementCoverages.find(
        (coverage) => Number(coverage.id) === item.id,
      )?.defectStatusStats,
    }));
  }
}

function shouldFetchCoverage(sourceBranch?: string): boolean {
  if (!sourceBranch) {
    return false;
  }

  return /\d/.test(sourceBranch);
}

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }

  if (typeof error === "string") {
    return error;
  }

  if (error && typeof error === "object") {
    try {
      return JSON.stringify(error);
    } catch {
      return "[unserializable error object]";
    }
  }

  return "Unknown error";
}

function parseCoverageSummary(value: unknown): AdoCoverageSummary | null {
  if (!value || typeof value !== "object") {
    return null;
  }

  const summary = value as Record<string, unknown>;
  if (
    typeof summary.lineCoverage !== "number" ||
    typeof summary.branchCoverage !== "number"
  ) {
    return null;
  }

  return {
    lineCoverage: summary.lineCoverage,
    branchCoverage: summary.branchCoverage,
  };
}

