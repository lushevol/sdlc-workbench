import {
  type GitCommitDiffs,
  GitVersionType,
} from "azure-devops-node-api/interfaces/GitInterfaces";
import type { AdoWebApi } from "./interfaces";
import { getReleasedPipelineRuns } from "./pipeline";

type GitContext = {
  getAdoClient(): AdoWebApi;
  getProjectName(): string;
};

export type CommitFileChange = {
  path: string;
  lineRanges: Array<{
    startLine: number;
    endLine: number;
  }>;
};

export type ReleaseGraphCommit = {
  commitId: string;
  comment: string;
  author?: string;
  date?: string;
  changes: CommitFileChange[];
};

export async function getFileContent(
  this: GitContext,
  repo: string,
  filePath: string,
  branch: string = "main",
) {
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();

  const res = await gitApi.getItemContent(
    repo,
    filePath,
    projectName,
    undefined,
    0,
    true,
    true,
    false,
    { version: branch, versionOptions: 0, versionType: 0 },
    true,
    true,
    true,
  );

  // Read Node.js Readable stream to string
  const chunks: Buffer[] = [];
  for await (const chunk of res) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString("utf-8");
}

export async function getBranchLatestCommit(
  this: GitContext,
  repoName: string,
  branchName = "main",
) {
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();
  const branch = await gitApi.getBranch(repoName, branchName, projectName);
  return branch?.commit?.commitId ?? "";
}

export async function commitCompare(
  this: GitContext,
  {
  repoName,
  baseCommit,
  targetCommit,
  }: {
    repoName: string;
    baseCommit: string;
    targetCommit: string;
  },
) {
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();

  if (!baseCommit || !targetCommit) return null;

  const diff = await gitApi.getCommitDiffs(
    repoName,
    projectName,
    true,
    undefined,
    undefined,
    { version: baseCommit, versionType: GitVersionType.Commit },
    { version: targetCommit, versionType: GitVersionType.Commit },
  );
  return diff;
}

export async function compareWithReleasedProd(
  this: GitContext,
  {
  repoName,
  baseCommit,
  }: {
    repoName: string;
    baseCommit: string;
  },
): Promise<{
  diff: GitCommitDiffs;
  prodBranch: string;
  prodCommit: string;
} | null> {
  if (!baseCommit) return null;
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();

  const runs = await (
    getReleasedPipelineRuns.bind(this) as typeof getReleasedPipelineRuns
  )(repoName);

  const run = runs.at(0);
  if (!run) return null;
  const releaseCommit = run?.run.sourceVersion;
  const prodBranch = run?.run.sourceBranch;
  if (!releaseCommit) return null;
  const diff = await gitApi.getCommitDiffs(
    repoName,
    projectName,
    false,
    undefined,
    undefined,
    { version: releaseCommit, versionType: GitVersionType.Commit },
    { version: baseCommit, versionType: GitVersionType.Commit },
  );

  return {
    diff,
    prodBranch: prodBranch.replace("refs/heads/", ""),
    prodCommit: releaseCommit,
  };
}

export async function getCommitsBatch(
  this: GitContext,
  repoName: string,
  baseCommit: string,
  targetCommit: string,
) {
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();

  const commits = await gitApi.getCommitsBatch(
    {
      itemVersion: { version: baseCommit, versionType: GitVersionType.Commit },
      compareVersion: {
        version: targetCommit,
        versionType: GitVersionType.Commit,
      },
    },
    repoName,
    projectName,
  );

  return commits;
}

function mapLineRanges(
  lineRanges: unknown,
): Array<{ startLine: number; endLine: number }> {
  if (!Array.isArray(lineRanges)) {
    return [];
  }

  return lineRanges.flatMap((lineRange) => {
    if (
      !lineRange ||
      typeof lineRange !== "object" ||
      typeof lineRange.startLine !== "number" ||
      typeof lineRange.endLine !== "number"
    ) {
      return [];
    }

    return [
      {
        startLine: lineRange.startLine,
        endLine: lineRange.endLine,
      },
    ];
  });
}

function mapCommitChanges(changes: unknown): CommitFileChange[] {
  if (!Array.isArray(changes)) {
    return [];
  }

  return changes.flatMap((change) => {
    if (!change || typeof change !== "object") {
      return [];
    }

    const path = change.item?.path;
    if (typeof path !== "string" || !path) {
      return [];
    }

    return [
      {
        path,
        lineRanges: mapLineRanges(change.lineRanges),
      },
    ];
  });
}

export async function getReleaseGraphCommitData(
  this: GitContext,
  repoName: string,
  targetCommit: string,
  baseCommit?: string,
): Promise<ReleaseGraphCommit[]> {
  const webApi = this.getAdoClient();
  const projectName = this.getProjectName();
  const gitApi = await webApi.getGitApi();

  if (!targetCommit) {
    return [];
  }

  const commits = await gitApi.getCommitsBatch(
    {
      itemVersion: baseCommit
        ? { version: baseCommit, versionType: GitVersionType.Commit }
        : undefined,
      compareVersion: {
        version: targetCommit,
        versionType: GitVersionType.Commit,
      },
    },
    repoName,
    projectName,
  );

  return Promise.all(
    commits.map(async (commit) => {
      const commitId = commit.commitId ?? "";
      const compareBaseCommit = commit.parents?.[0] ?? baseCommit ?? "";
      let diff;
      if (commitId && compareBaseCommit) {
        try {
          diff = await gitApi.getCommitDiffs(
            repoName,
            projectName,
            false,
            undefined,
            undefined,
            {
              version: compareBaseCommit,
              versionType: GitVersionType.Commit,
            },
            { version: commitId, versionType: GitVersionType.Commit },
          );
        } catch {
          diff = undefined;
        }
      }

      return {
        commitId,
        comment: commit.comment ?? "",
        author: commit.author?.name,
        date: commit.author?.date?.toString(),
        changes: mapCommitChanges(diff?.changes),
      } satisfies ReleaseGraphCommit;
    }),
  );
}

export async function getReleaseDiffChecking(
  this: GitContext,
  repoName: string,
  branchName: string,
  commit: string,
): Promise<{
  diffWithLatestCommit: GitCommitDiffs;
  diffWithReleasedProd: GitCommitDiffs;
  diffWithMainBranch: GitCommitDiffs | null;
  mainDiffWithProd: GitCommitDiffs | null;
  behindMainAllMergeCommit: boolean | null;
  behindProdAllMergeCommit: boolean | null;
  mainBehindProdAllMergeCommit: boolean | null;
  latestBranchCommit: string;
  mainBranchCommit: string | null;
  prodCommit: string;
  prodBranch: string;
}> {
  const MERGE = "Merge";
  const isMain = branchName === "main";
  const latestBranchCommit = await getBranchLatestCommit.call(
    this,
    repoName,
    branchName,
  );

  // Compare with latest commit in the branch
  const diffWithLatestCommit = await commitCompare.call(this, {
    repoName,
    baseCommit: latestBranchCommit,
    targetCommit: commit,
  });

  // Compare with prod version
  let behindProdAllMergeCommit: boolean | null = null;
  const {
    diff: diffWithReleasedProd,
    prodBranch = "",
    prodCommit = "",
  } = (await compareWithReleasedProd.call(this, {
    repoName,
    baseCommit: commit,
  })) ?? {};
  if (Number(diffWithReleasedProd?.behindCount) > 0) {
    const commits = await getCommitsBatch.call(this, repoName, commit, prodCommit);

    behindProdAllMergeCommit = commits.every((c: { comment?: string }) =>
      c.comment?.startsWith(MERGE),
    );
  }

  let behindMainAllMergeCommit: boolean | null = null;
  let mainBehindProdAllMergeCommit: boolean | null = null;
  if (!isMain) {
    // Compare with main branch
    const mainBranchCommit = await getBranchLatestCommit.call(
      this,
      repoName,
      "main",
    );

    const diffWithMainBranch = await commitCompare.call(this, {
      repoName,
      baseCommit: mainBranchCommit,
      targetCommit: commit,
    });
    if (Number(diffWithMainBranch?.behindCount) > 0) {
      const commits = await getCommitsBatch.call(
        this,
        repoName,
        commit,
        mainBranchCommit,
      );

      behindMainAllMergeCommit = commits.every((c: { comment?: string }) =>
        c.comment?.startsWith(MERGE),
      );
    }

    // Main compare with Prod
    const { diff: mainDiffWithProd } =
      (await compareWithReleasedProd.call(this, {
        repoName,
        baseCommit: mainBranchCommit,
      })) ?? {};
    if (Number(mainDiffWithProd?.aheadCount) > 0) {
      const commits = await getCommitsBatch.call(
        this,
        repoName,
        mainBranchCommit,
        prodCommit,
      );

      mainBehindProdAllMergeCommit = commits.every((c: { comment?: string }) =>
        c.comment?.startsWith(MERGE),
      );
    }

    return {
      diffWithLatestCommit: {
        ...diffWithLatestCommit,
        changes: [],
      },
      diffWithReleasedProd: {
        ...diffWithReleasedProd,
        changes: [],
      },
      diffWithMainBranch: {
        ...diffWithMainBranch,
        changes: [],
      },
      mainDiffWithProd: {
        ...mainDiffWithProd,
        changes: [],
      },
      behindMainAllMergeCommit,
      behindProdAllMergeCommit,
      mainBehindProdAllMergeCommit,
      prodCommit,
      prodBranch,
      latestBranchCommit,
      mainBranchCommit,
    };
  }

  return {
    diffWithLatestCommit: {
      ...diffWithLatestCommit,
      changes: [],
    },
    diffWithReleasedProd: {
      ...diffWithReleasedProd,
      changes: [],
    },
    diffWithMainBranch: null,
    mainDiffWithProd: null,
    behindMainAllMergeCommit,
    behindProdAllMergeCommit,
    mainBehindProdAllMergeCommit,
    prodBranch,
    prodCommit,
    latestBranchCommit,
    mainBranchCommit: null,
  };
}
