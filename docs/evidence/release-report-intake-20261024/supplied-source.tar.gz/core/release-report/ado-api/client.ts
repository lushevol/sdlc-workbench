import * as vm from "azure-devops-node-api";
import type { IRequestOptions } from "azure-devops-node-api/interfaces/common/VsoBaseInterfaces.js";
import {
  getArtifactsByBuildId,
  getBuildAttachmentContent,
  getBuildAttachments,
  getBuildById,
  getBuildChangesByBuildId,
  getBuildLogsByBuildId,
  getBuildPropertiesByBuildId,
  getBuildReportByBuildId,
} from "./build";
import {
  getCoverageSummaryByBranchName,
  getCoverageSummaryByBuildId,
  getCoverageSummaryByPullRequestId,
} from "./coverage";
import config from "./config.json" with { type: "json" };
import { getCodeDiffFromHierarchyQuery } from "./extension/CodeDiff";
import {
  commitCompare,
  getBranchLatestCommit,
  getFileContent,
  getReleaseGraphCommitData,
  getReleaseDiffChecking,
} from "./git";
import type { AdoWebApi } from "./interfaces";
import { getSubscriptions } from "./notification";
import {
  getPipelineByRepoName,
  getPipelineRuns,
  getReleasedPipelineRuns,
} from "./pipeline";
import {
  getLatestPullRequestIterations,
  getLatestPullRequestStatus,
  getPullRequestById,
  getPullRequestChangesFiles,
  getPullRequestIterationChangesFiles,
  getPullRequestIterations,
  getPullRequestListByRepoName,
  getPullRequestProperties,
  getPullRequestsByBranchName,
  hasAlreadyCommented,
  isValidPullRequest,
  setPullRequestProperties,
} from "./pull-request";
import {
  addCommentForPR,
  addCommentThreadForPRCode,
  getCommentThreadById,
  updateCommentThreadStatus,
} from "./pull-request-comment";
import { getReleaseWorkItems, queryRatanReleaseIds } from "./release";
import {
  getLinkedReleaseComplianceStories,
  getReleaseComplianceAssessment,
  getReleaseComplianceAssessments,
  getReleaseComplianceFields,
} from "./release-compliance";
import { getRepos } from "./repo";
import {
  createTestCaseWorkItem,
  getTestCaseWorkItems,
  updateTestCaseWorkItem,
} from "./testcase";
import {
  createBulkTestSuites,
  createTestPlan,
  createTestSuite,
  getTestPlanById,
  getTestPointList,
  getTestSuite,
  updateTestPlan,
} from "./testplan";
import {
  createTestRun,
  createTestRunResults,
  createTestRunResultsAttachments,
  getTestRun,
  getTestRunResults,
  queryTestRunResults,
  updateTestRun,
  updateTestRunResults,
} from "./testrun";
import {
  addRelationsToWorkItem,
  getCommonWorkItems,
  getWorkitemsByFields,
} from "./workitem";
import {
  queryWorkitemsByQueryId,
  queryWorkitemsByWiql,
} from "./workitem-query";
export class AzureDevOps {
  private adoWebApi: AdoWebApi;
  private API_URL = "https://dev.azure.com";
  private API_ORGANIZATION = "sc-ado";
  private API_PROJECT = "FMQPR";
  private API_TOKEN = "";
  private ADO_PROXY_URL = config.ADO_PROXY_URL || "";

  constructor({
    proxy,
    organization,
    project,
  }: {
    proxy?: string;
    organization?: string;
    project?: string;
  } = {}) {
    if (proxy) {
      this.ADO_PROXY_URL = proxy;
    }
    if (organization) {
      this.API_ORGANIZATION = organization;
    }
    if (project) {
      this.API_PROJECT = project;
    }
  }

  async connect(token: string) {
    if (!token) {
      console.error("ADO token is required for authentication.");
      throw new Error("ADO token is required for authentication.");
    }
    try {
      this.API_TOKEN = token;
      const authHandler = vm.getPersonalAccessTokenHandler(this.API_TOKEN);
      const option: IRequestOptions = {
        proxy: {
          proxyUrl: this.ADO_PROXY_URL,
        },
        ignoreSslError: true,
      };

      const vsts: vm.WebApi = new vm.WebApi(
        this.getServerUrl(),
        authHandler,
        option,
      );
      const connData = await vsts.connect();
      const currentUserName =
        connData.authenticatedUser?.providerDisplayName || "UNKNOWN_USER";
      console.log(`${currentUserName} ADO Login Successfully`);
      this.adoWebApi = vsts;
      return connData;
    } catch (err) {
      console.error("Error connecting to Azure DevOps:", err);
      throw err;
    }
  }

  getServerUrl() {
    return `${this.API_URL}/${this.API_ORGANIZATION}`;
  }

  getOrganization() {
    return this.API_ORGANIZATION;
  }

  getProjectName() {
    return this.API_PROJECT;
  }

  getAdoToken() {
    return this.API_TOKEN;
  }

  getProxyUrl() {
    return this.ADO_PROXY_URL;
  }

  getAdoClient() {
    return this.adoWebApi;
  }

  getPullRequestListByRepoName = getPullRequestListByRepoName;
  getPullRequestById = getPullRequestById;
  getRepos = getRepos;
  getBranchLatestCommit = getBranchLatestCommit;
  commitCompare = commitCompare;
  getReleaseGraphCommitData = getReleaseGraphCommitData;
  getReleaseDiffChecking = getReleaseDiffChecking;
  getPipelineRuns = getPipelineRuns;
  getReleasedPipelineRuns = getReleasedPipelineRuns;
  getPipelineByRepoName = getPipelineByRepoName;
  getPullRequestsByBranchName = getPullRequestsByBranchName;
  getPullRequestIterations = getPullRequestIterations;
  getLatestPullRequestIterations = getLatestPullRequestIterations;
  getPullRequestIterationChangesFiles = getPullRequestIterationChangesFiles;
  getPullRequestProperties = getPullRequestProperties;
  setPullRequestProperties = setPullRequestProperties;
  getPullRequestChangesFiles = getPullRequestChangesFiles;
  getCodeDiffFromHierarchyQuery = getCodeDiffFromHierarchyQuery;
  isValidPullRequest = isValidPullRequest;
  hasAlreadyCommented = hasAlreadyCommented;
  getLatestPullRequestStatus = getLatestPullRequestStatus;
  getWorkitemsByFields = getWorkitemsByFields;
  getCommonWorkItems = getCommonWorkItems;
  getReleaseComplianceFields = getReleaseComplianceFields;
  getLinkedReleaseComplianceStories = getLinkedReleaseComplianceStories;
  getReleaseComplianceAssessment = getReleaseComplianceAssessment;
  getReleaseComplianceAssessments = getReleaseComplianceAssessments;
  getReleaseWorkItems = getReleaseWorkItems;
  getTestCaseWorkItems = getTestCaseWorkItems;
  addRelationsToWorkItem = addRelationsToWorkItem;
  queryRatanReleaseIds = queryRatanReleaseIds;
  createTestCaseWorkItem = createTestCaseWorkItem;
  updateTestCaseWorkItem = updateTestCaseWorkItem;
  addCommentForPR = addCommentForPR;
  addCommentThreadForPRCode = addCommentThreadForPRCode;
  getCommentThreadById = getCommentThreadById;
  updateCommentThreadStatus = updateCommentThreadStatus;
  getSubscriptions = getSubscriptions;
  getBuildById = getBuildById;
  getBuildAttachmentContent = getBuildAttachmentContent;
  getBuildAttachments = getBuildAttachments;
  getArtifactsByBuildId = getArtifactsByBuildId;
  getCoverageSummaryByBuildId = async (buildId: number) =>
    getCoverageSummaryByBuildId(this, buildId);
  getCoverageSummaryByBranchName = async (branchName: string, repoName: string) =>
    getCoverageSummaryByBranchName(this, branchName, repoName);
  getCoverageSummaryByPullRequestId = async (
    pullRequestId: number,
    repoName: string,
  ) => getCoverageSummaryByPullRequestId(this, pullRequestId, repoName);
  getBuildChangesByBuildId = getBuildChangesByBuildId;
  getBuildLogsByBuildId = getBuildLogsByBuildId;
  getBuildPropertiesByBuildId = getBuildPropertiesByBuildId;
  getBuildReportByBuildId = getBuildReportByBuildId;
  queryWorkitemsByQueryId = queryWorkitemsByQueryId;
  queryWorkitemsByWiql = queryWorkitemsByWiql;
  createTestRun = createTestRun;
  getTestRunResults = getTestRunResults;
  queryTestRunResults = queryTestRunResults;
  createTestRunResults = createTestRunResults;
  updateTestRunResults = updateTestRunResults;
  createTestRunResultsAttachments = createTestRunResultsAttachments;
  getTestPlanById = getTestPlanById;
  createTestPlan = createTestPlan;
  updateTestPlan = updateTestPlan;
  getTestSuite = getTestSuite;
  createTestSuite = createTestSuite;
  createBulkTestSuites = createBulkTestSuites;
  getTestRun = getTestRun;
  updateTestRun = updateTestRun;
  getTestPointList = getTestPointList;
  getFileContent = getFileContent;
}
