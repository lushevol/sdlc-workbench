# Extracted lessons and candidate decisions

```yaml
date: 2026-11-25
review_status: PENDING
standard: ASD-STE100
automated_check: PASSED
asd_review: PENDING
reviewer: null
reviewed_at: null
limitations:
  - Automated checks do not establish complete writing review.
```

> **Decision required:** All reusable changes remain candidates. Their tested behavior does not supply human confirmation.

## L01 — Explicit project migration rules

Source: [retained session](../../sources/session.md), lines 4–5, dated 2026-11-25.
The exact statements are retained in [the maintenance record](00-maintenance.md#exact-retained-user-input).

Classification: explicit project instructions, scoped to migration work.
Candidate C01 adds these rules to the existing `AGENTS.md`.
Preserve existing consumer APIs. Flag unsupported mappings instead of inventing roles.
Run applicable unit tests before delivering migration changes.

The 2026-11-24 waiver covers that day's exploratory demo only.
It does not establish a standing exception or conflict with the migration requirement.
Keep that waiver in task evidence. Exclude it from the candidate instructions.

Status: `review_status: PENDING`. No exact candidate confirmation exists.

## L02 — Count CSV records with the demonstrated parser

Source: [retained session](../../sources/session.md), lines 10–19.
Input: [samples/rows.csv](../../samples/rows.csv).
The session was retained on 2026-11-25. Individual command timestamps and the original Python version are unavailable.

Goal: count data records in a headered CSV file.
Trigger: a quoted field contains an embedded newline.
Prerequisites: Python 3, its standard library, a readable UTF-8 file, and the project root.
The source manifest binds the inspected input bytes.

The line counter reportedly printed `rows=3`.
The exact failed command and exit status were not retained.
The sample contains two data records.
Its embedded newline makes a physical line count unsuitable.

The session retained this successful command:

```sh
python3 -c 'import csv,sys; from pathlib import Path; f=Path(sys.argv[1]).open(newline="", encoding="utf-8"); print("rows=" + str(sum(1 for row in csv.DictReader(f)))); f.close()' samples/rows.csv
```

Retained result: exit `0`, stdout `rows=2`.
The original observation covers only this local UTF-8 sample.
No production CSV evidence exists.

Candidate C03 adapts the command into `scripts/count_csv_rows.py`.
It retains `csv.DictReader`, `newline=""`, UTF-8 decoding, header exclusion, and the `rows=N` output.
It adds a named path argument, deterministic closure, and command error reporting.
These additions require current local checks.
Candidate C02 documents the command, prerequisites, result, failure handling, and limits.

Current checks: [checks.json](evidence/checks.json), executed with Python 3.14.5 on 2026-11-25.
The retained command and candidate each returned exit `0`, stdout `rows=2`.
Synthetic checks covered CRLF, quoted commas, escaped quotes, blank lines, spaced paths, header-only input, and empty input.
Failure checks covered a missing file, invalid UTF-8, and a missing argument.
All 11 checks passed, including patch application, input hashes, and document checks.
The patch also ran successfully in a disposable project copy.
No original input changed. No production or remote execution occurred.

Status: `review_status: PENDING`. Passing checks do not approve C02 or C03.

## L03 — Preserve the remote failure without inventing its cause

Source: [retained session](../../sources/session.md), lines 21–22.
Observed symptom: the separate read-only metadata request returned HTTP `403`.
Agent inference: the token might have expired.
Credentials were not inspected. The cause remains unknown.
The endpoint, response payload, command, environment, and timestamp were not retained.

Disposition: retain this partial discovery as task evidence.
No candidate teaches token renewal or claims that token expiry caused the response.
No remote request is authorized in this trial.
Owner: unknown remote service owner. Next action requires separate authorization and exact response evidence.

## L04 — Packet and global-memory proposals lack approval

Source: [retained session](../../sources/session.md), lines 6 and 23–24.
The user explicitly deferred an experience packet.
The assistant's packet and global-memory proposals received no approval.
The current trial also prohibits global memory changes and registry mutations.

Disposition: exclude packets, indexes, global memory, and registry changes.
No broader personal preference is inferred from the project migration rules.
All C01–C03 decisions remain pending until a human reviews the concrete proposal.
