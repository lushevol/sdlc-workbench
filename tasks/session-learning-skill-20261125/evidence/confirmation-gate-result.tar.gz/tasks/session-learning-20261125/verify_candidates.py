"""Run offline checks against task-local candidates without activating them."""

import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile


TASK = Path(__file__).resolve().parent
ROOT = TASK.parent.parent
MANIFEST = json.loads((TASK / "evidence/source-manifest.json").read_text())
SCRIPT = TASK / "candidates/scripts/count_csv_rows.py"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
RESULTS = []


def check(name, action):
    entry = {"name": name, "status": "PASSED"}
    try:
        details = action()
        if details is not None:
            entry["evidence"] = details
    except Exception as error:
        entry["status"] = "FAILED"
        entry["error"] = f"{type(error).__name__}: {error}"
    RESULTS.append(entry)


def command_case(command, expected_code, expected_stdout, cwd=ROOT, error_text=None):
    result = subprocess.run(
        command, cwd=cwd, env=ENV, capture_output=True, text=True, timeout=10
    )
    actual = {
        "command": command, "cwd": str(cwd), "exit": result.returncode,
        "stdout": result.stdout, "stderr": result.stderr,
    }
    assert result.returncode == expected_code, actual
    assert result.stdout == expected_stdout, actual
    if error_text is None:
        assert result.stderr == "", actual
    else:
        assert error_text in result.stderr, actual
    return actual


def verify_bindings():
    for entry in MANIFEST["inputs"]:
        actual = hashlib.sha256((ROOT / entry["path"]).read_bytes()).hexdigest()
        assert actual == entry["sha256"], entry["path"]
    for entry in MANIFEST["candidates"]:
        actual = hashlib.sha256((ROOT / entry["draft"]).read_bytes()).hexdigest()
        assert actual == entry["sha256"], entry["id"]
        assert entry["review_status"] == "PENDING", entry["id"]
    assert not (ROOT / "scripts/count_csv_rows.py").exists()
    assert not (ROOT / "assets").exists()
    assert MANIFEST["confirmation"]["answer"] is None
    assert MANIFEST["confirmation"]["confirmed_candidates"] == []
    return "Four inputs unchanged; three candidate hashes match; no active script or packet."


def verify_documents():
    checked_links = []
    paths = [TASK / "00-maintenance.md", TASK / "lessons.md", ROOT / "outputs/response.md"]
    paths.extend(TASK / "candidates" / name for name in ("AGENTS.md", "docs/workflows.md"))
    for path in paths:
        text = path.read_text()
        assert text.endswith("\n"), str(path)
        assert all(line == line.rstrip() for line in text.splitlines()), str(path)
        for target in re.findall(r"\[[^\]\n]+\]\(([^)\n]+)\)", text):
            target_path = target.split("#", 1)[0]
            if not target_path:
                continue
            # Draft links use the document's eventual project location.
            base = path.parent
            if path.is_relative_to(TASK / "candidates"):
                base = (ROOT / path.relative_to(TASK / "candidates")).parent
            resolved = (base / target_path).resolve()
            assert resolved.exists(), f"{path}: {target}"
            checked_links.append({"document": str(path.relative_to(ROOT)), "target": target})
    for path in paths[:3]:
        text = path.read_text()
        assert "standard: ASD-STE100" in text
        assert "asd_review: PENDING" in text
    instructions = (TASK / "candidates/AGENTS.md").read_text()
    assert (ROOT / "AGENTS.md").read_text().rstrip() in instructions
    assert "For migration work in this project" in instructions
    assert "Run applicable unit tests before delivering migration changes." in instructions
    assert "skip offline checks" not in instructions
    return {"checked_links": checked_links, "draft_links_checked_at": "intended target locations"}


(TASK / "evidence/checks.json").write_text(json.dumps({
    "date": "2026-11-25", "status": "RUNNING", "results": [],
    "note": "The final report replaces this marker when execution completes.",
}, indent=2) + "\n")

with tempfile.TemporaryDirectory(prefix="offline-check-", dir=TASK / "evidence") as scratch_name:
    scratch = Path(scratch_name)
    fixture = scratch / "quoted records.csv"
    fixture.write_bytes(b'name,note\r\nalpha,"comma, quote ""yes""\r\nsecond line"\r\nbeta,plain\r\n\r\n')
    header_only = scratch / "headers.csv"
    header_only.write_text("name,note\n")
    empty = scratch / "empty.csv"
    empty.write_bytes(b"")
    invalid = scratch / "invalid-utf8.csv"
    invalid.write_bytes(b"name,note\nalpha,\xff\n")

    original_code = (
        'import csv,sys; from pathlib import Path; '
        'f=Path(sys.argv[1]).open(newline="", encoding="utf-8"); '
        'print("rows=" + str(sum(1 for row in csv.DictReader(f)))); f.close()'
    )
    check("retained_command_replay", lambda: command_case(
        [sys.executable, "-c", original_code, "samples/rows.csv"], 0, "rows=2\n"
    ))
    check("candidate_retained_multiline_sample", lambda: command_case(
        [sys.executable, str(SCRIPT), "samples/rows.csv"], 0, "rows=2\n"
    ))
    check("synthetic_crlf_quotes_commas_blank_line_and_spaced_path", lambda: command_case(
        [sys.executable, str(SCRIPT), str(fixture)], 0, "rows=2\n"
    ))
    check("synthetic_header_only", lambda: command_case(
        [sys.executable, str(SCRIPT), str(header_only)], 0, "rows=0\n"
    ))
    check("synthetic_empty_file", lambda: command_case(
        [sys.executable, str(SCRIPT), str(empty)], 0, "rows=0\n"
    ))
    check("missing_file", lambda: command_case(
        [sys.executable, str(SCRIPT), str(scratch / "absent.csv")], 1, "", error_text="error:"
    ))
    check("invalid_utf8", lambda: command_case(
        [sys.executable, str(SCRIPT), str(invalid)], 1, "", error_text="error:"
    ))
    check("missing_argument", lambda: command_case(
        [sys.executable, str(SCRIPT)], 2, "", error_text="required"
    ))

    def verify_patch():
        project = scratch / "project"
        project.mkdir()
        for entry in MANIFEST["inputs"]:
            target = project / entry["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / entry["path"], target)
        patch = str(TASK / "proposed-changes.patch")
        commands = [
            command_case(["git", "apply", "--check", "--whitespace=error", patch], 0, "", cwd=project),
            command_case(["git", "apply", "--whitespace=error", patch], 0, "", cwd=project),
        ]
        for entry in MANIFEST["candidates"]:
            assert (project / entry["target"]).read_bytes() == (ROOT / entry["draft"]).read_bytes()
        commands.append(command_case(
            [sys.executable, "scripts/count_csv_rows.py", "samples/rows.csv"], 0, "rows=2\n", cwd=project
        ))
        return {"commands": commands, "result": "Patched disposable project matches all candidate bytes."}

    check("exact_patch_application_and_documented_command", verify_patch)

check("source_and_candidate_hashes_and_no_activation", verify_bindings)
check("document_links_metadata_and_scope", verify_documents)

report = {
    "date": "2026-11-25", "status": "PASSED" if all(x["status"] == "PASSED" for x in RESULTS) else "FAILED",
    "python_version": platform.python_version(), "python_executable": sys.executable,
    "checks_run": len(RESULTS), "passed": sum(x["status"] == "PASSED" for x in RESULTS),
    "failed": sum(x["status"] == "FAILED" for x in RESULTS), "skipped": 0,
    "results": RESULTS,
    "limits": [
        "Offline local checks only; temporary fixtures were synthetic and removed.",
        "No production CSV, remote request, migration application suite, or semantic ASD review was executed.",
        "Document links were checked for target existence; draft links use their intended project locations.",
        "Passing checks do not confirm candidates or establish a cause for the retained HTTP 403.",
    ],
}
(TASK / "evidence/checks.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "checks_run", "passed", "failed", "skipped")}))
for result in RESULTS:
    if result["status"] != "PASSED":
        print(json.dumps(result))
raise SystemExit(0 if report["status"] == "PASSED" else 1)
