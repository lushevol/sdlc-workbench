"""Count data records in a headered UTF-8 CSV file."""

import argparse
import csv
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(
        description="Count data records in a headered UTF-8 CSV file."
    )
    parser.add_argument("csv_file", type=Path, help="CSV path relative to the current directory")
    args = parser.parse_args()
    try:
        with args.csv_file.open(newline="", encoding="utf-8") as source:
            count = sum(1 for row in csv.DictReader(source))
    except (OSError, UnicodeError, csv.Error) as error:
        parser.exit(1, f"error: {error}\n")
    print(f"rows={count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
