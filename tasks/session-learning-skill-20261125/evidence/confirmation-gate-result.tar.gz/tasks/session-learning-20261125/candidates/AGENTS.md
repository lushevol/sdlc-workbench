# Sample project

Use docs/workflows.md for CSV procedures.

## Migration work

For migration work in this project, preserve existing consumer APIs.
Flag unsupported mappings instead of inventing roles.
Run applicable unit tests before delivering migration changes.
