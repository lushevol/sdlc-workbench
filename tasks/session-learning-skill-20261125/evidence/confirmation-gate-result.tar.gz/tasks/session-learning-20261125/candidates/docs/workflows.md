# CSV row count

Use a CSV parser to count data records.
Quoted fields can contain newlines.
The first CSV record supplies column headers and is excluded from the count.
Empty physical lines are ignored by `csv.DictReader`.

## Prerequisites

Use Python 3 and its standard library.
Supply a readable UTF-8 file with headers.
The procedure uses Python's default comma-separated CSV dialect.
Run commands from the project root.
Resolve relative input paths against the current directory.

## Procedure

Run the reusable script:

```sh
python3 scripts/count_csv_rows.py samples/rows.csv
```

Replace `samples/rows.csv` with the required CSV path.
The script reads the input without changing it.
A successful run exits with status `0` and prints `rows=N`.

For the retained sample, expect:

```text
rows=2
```

Check the exit status as well as standard output.
Missing arguments exit with status `2`.
File access, decoding, or reported parser errors exit with status `1`.
Errors appear on standard error without a count.
Check the path, read access, encoding, and supplied file before retrying.

## Verification and limits

The retained command returned `rows=2` for `samples/rows.csv`.
One quoted field contains an embedded newline.
The earlier physical line counter returned `rows=3`.
Use record parsing for this case.

Task-local checks cover the retained sample and labeled synthetic inputs.
These checks do not establish production suitability.
The script counts parser records; it does not validate required columns or business data.
Files without headers and custom dialects require a separate decision and verification.

Source and current check evidence: [session learning review](../tasks/session-learning-20261125/00-maintenance.md).
