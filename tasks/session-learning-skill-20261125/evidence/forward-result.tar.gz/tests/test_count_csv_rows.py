"""Offline CLI checks using retained and synthetic CSV inputs."""

from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "count_csv_rows.py"


class CountCsvRowsTests(unittest.TestCase):
    def setUp(self):
        self.workspace = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.workspace.cleanup)
        self.directory = Path(self.workspace.name)

    def run_script(self, *arguments, cwd=None):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *(str(value) for value in arguments)],
            cwd=cwd or ROOT,
            capture_output=True,
            text=True,
            check=False,
        )

    def assert_success(self, result, count):
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, f"rows={count}\n")
        self.assertEqual(result.stderr, "")

    def assert_input_error(self, result):
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn("error:", result.stderr)
        self.assertNotIn("Traceback", result.stderr)

    def test_retained_sample(self):
        sample = ROOT / "samples" / "rows.csv"
        before = sample.read_bytes()
        self.assert_success(self.run_script(sample), 2)
        self.assertEqual(sample.read_bytes(), before)

    def test_quoted_utf8_records_from_another_directory(self):
        sample = self.directory / "quoted records.csv"
        content = (
            'name,note\r\ncafé,"deux\r\nlignes, suite"\r\n'
            'beta,"quoted ""word"""\r\n'
        ).encode("utf-8")
        sample.write_bytes(content)
        result = self.run_script(sample.name, cwd=self.directory)
        self.assert_success(result, 2)
        self.assertEqual(sample.read_bytes(), content)

    def test_empty_and_header_only(self):
        sample = self.directory / "empty.csv"
        for content in ("", "name,note\n"):
            with self.subTest(content=content):
                sample.write_text(content, encoding="utf-8")
                self.assert_success(self.run_script(sample), 0)

    def test_missing_file(self):
        self.assert_input_error(self.run_script(self.directory / "missing.csv"))

    def test_directory_path(self):
        self.assert_input_error(self.run_script(self.directory))

    def test_invalid_utf8(self):
        sample = self.directory / "invalid.csv"
        sample.write_bytes(b"name,note\nalpha,\xff\n")
        self.assert_input_error(self.run_script(sample))

    def test_missing_argument(self):
        result = self.run_script()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("usage:", result.stderr)
        self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
