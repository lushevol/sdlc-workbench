# Sample project

Use [docs/workflows.md](docs/workflows.md) for CSV procedures.

For migration work in this project:

- Preserve existing consumer APIs.
- Flag unsupported mappings. Do not invent roles.
- Run applicable unit tests before delivering migration changes.

These explicit project instructions come from the [November 25 session](sources/session.md).
The November 24 offline-check waiver applied only to that day's exploratory demo.
It does not waive checks for later work.
