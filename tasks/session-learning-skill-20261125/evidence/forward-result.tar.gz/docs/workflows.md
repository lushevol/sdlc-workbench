# CSV row count

Use Python's CSV parser to count data records after the header.
Quoted fields can contain newlines. Physical line counts do not count CSV records correctly.

## Run

Prerequisites: Python 3 and a readable UTF-8 CSV file with a header.
The script uses only the Python standard library.

From the project root:

```sh
python3 scripts/count_csv_rows.py samples/rows.csv
```

Expected output:

```text
rows=2
```

Replace `samples/rows.csv` with the input path.
Relative input paths resolve from the current working directory.
Elsewhere, use the script's absolute path and the required input path.

The script opens the file with `newline=""` and `encoding="utf-8"`.
It counts records from `csv.DictReader` and closes the file after reading.
Empty files and files containing only a header produce `rows=0`.
Blank lines follow the parser's default handling.
The script reads the input without changing it.

Success returns exit status 0.
File, decoding, or parser errors return status 1 with an error on standard error.
Missing arguments return status 2.
Correct the path, access, encoding, or reported input problem before retrying.
Do not substitute physical line counting after a failure.

## Verify locally

Run from the project root:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

The tests cover the retained sample, quoted newlines, commas, escaped quotes, UTF-8 text, and another working directory.
They also cover empty input, headers without records, missing files, directory paths, invalid UTF-8, and missing arguments.

## Evidence and limits

The [retained session](../sources/session.md#exploration-and-attempts) reported `rows=3` from a physical line counter.
The parser command returned exit status 0 and `rows=2` for `samples/rows.csv`.
One quoted field contains a newline.
The reusable [script](../scripts/count_csv_rows.py) preserves that command's parser, encoding, and counting behavior.
It adds argument handling, automatic file closure, and readable failures.

The retained execution covered only this local UTF-8 sample.
The extraction adds local synthetic tests.
Neither result establishes production behavior or support for other encodings and CSV dialects.
Counting does not validate column names, row widths, or business data.

The separate remote request returned HTTP 403.
An expired token was suspected; the cause was not established.
That observation does not justify credential changes or remote retries.
