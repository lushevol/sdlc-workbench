"""Count data records in a UTF-8 CSV file with a header."""

import argparse
import csv
from pathlib import Path
import sys


def count_records(path: Path) -> int:
    with path.open(newline="", encoding="utf-8") as source:
        return sum(1 for _ in csv.DictReader(source))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="UTF-8 CSV input path")
    arguments = parser.parse_args()
    try:
        count = count_records(arguments.path)
    except (OSError, UnicodeError, csv.Error) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    print(f"rows={count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
