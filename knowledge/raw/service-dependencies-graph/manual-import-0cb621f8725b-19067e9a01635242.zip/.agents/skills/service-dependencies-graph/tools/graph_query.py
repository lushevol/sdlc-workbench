#!/usr/bin/env python3
"""Compatibility entry point for ratan_harness.graph.graph_query."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[4]))
from ratan_harness.graph import graph_query as _engine

if __name__ == "__main__":
    raise SystemExit("Import this module through ratan_harness.graph.")
else:
    sys.modules[__name__] = _engine
    globals().update(vars(_engine))
